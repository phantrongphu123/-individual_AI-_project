# app/controllers/game_controller.py
from app.models.puzzle_game import PuzzleGame
from app.models.puzzle_state import PuzzleState # Quan trọng cho việc tạo PuzzleState
from app.models.solvers.rl_agents import QLearningAgent # Thêm import
from app.models.solvers.rl_agents import QLearningAgent, SarsaAgent
# Import các lớp Solver bạn đã tạo
from app.models.solvers.search_solvers import (
    BFSSolver, DFSSolver, UCSSolver, IDSSolver, 
    GreedySolver, AStarSolver, IDAStarSolver
)
from app.models.solvers.local_search_solvers import (
    HillClimbingSolver, SimulatedAnnealingSolver, 
    GeneticAlgorithmSolver, BeamSearchSolver
)
# from app.models.solvers.csp_solvers import BacktrackingCSPSolver, MinConflictsSolver # Bỏ comment khi có
# from app.models.solvers.rl_agents import QLearningAgent # Bỏ comment khi có
import threading
import queue
import copy
import os # Để xử lý đường dẫn
import time # Có thể dùng cho việc log thời gian nếu cần, nhưng solver đã có timer riêng
# đi lên 2 cấp (..) để đến thư mục gốc dự án
PROJECT_ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DATA_DIR = os.path.join(PROJECT_ROOT_DIR, "data") # Đường dẫn đến thư mục data

# Tạo thư mục data nếu nó chưa tồn tại
if not os.path.exists(DATA_DIR):
    try:
        os.makedirs(DATA_DIR)
        print(f"GAME_CONTROLLER_INFO: Created data directory at {DATA_DIR}")
    except OSError as e:
        print(f"GAME_CONTROLLER_ERROR: Could not create data directory at {DATA_DIR}: {e}")
        # Có thể quyết định thoát hoặc tiếp tục mà không lưu/tải Q-table

class GameController:
    def __init__(self, size=3):
        self.game = PuzzleGame(size) # Model chính: quản lý trạng thái game 8-puzzle
        self.view = None             # Sẽ được gán từ main.py (là instance của PygameView)
        self.solver_thread = None    # Để chạy solver trong luồng riêng, tránh treo GUI
        self.solver_result_queue = queue.Queue() # Để giao tiếp kết quả từ luồng solver về luồng chính

    def set_view(self, view_instance):
        """Gán instance của View (PygameView) cho controller."""
        self.view = view_instance
        self._update_view_with_current_board() # Hiển thị bảng lần đầu khi view được gán

    def _update_view_with_current_board(self):
        """Yêu cầu View hiển thị trạng thái bảng hiện tại của game."""
        if self.view:
            current_state_to_display = self.game.get_current_state() # Lấy PuzzleState hiện tại từ model game
            self.view.display_board(current_state_to_display) # View có phương thức này
            if current_state_to_display:
                # self.view.show_message(f"Board {self.game.size}x{self.game.size} ready.", "info") # Có thể bỏ bớt thông báo này
                pass
            else: # Trường hợp current_state là None (ví dụ, game mới khởi tạo chưa có board)
                self.view.show_message(f"No board to display. Randomize or Input.", "info")


    def randomize_board(self):
        """Yêu cầu model game tạo một bảng ngẫu nhiên mới và cập nhật View."""
        if self.solver_thread and self.solver_thread.is_alive():
            if self.view: self.view.show_message("Cannot randomize while solver is running.", "warning")
            return
        self.game.randomize_board()
        if self.view: self._update_view_with_current_board()

    def reset_board(self):
        """Yêu cầu model game reset bảng về trạng thái ngẫu nhiên cuối cùng và cập nhật View."""
        if self.solver_thread and self.solver_thread.is_alive():
            if self.view: self.view.show_message("Cannot reset while solver is running.", "warning")
            return
        self.game.reset_board_to_last_random()
        if self.view: self._update_view_with_current_board()

    def set_custom_board(self, board_array_from_view):
        """
        Thiết lập một bảng tùy chỉnh từ input của người dùng (thông qua View).
        board_array_from_view là một list of lists, ví dụ: [[1,2,3],[4,5,0],[7,8,6]]
        """
        if not self.view:
            print("CONTROLLER_ERROR: View not set in set_custom_board.")
            return

        try:
            # Kiểm tra tính giải được của bảng người dùng nhập TRƯỚC KHI tạo PuzzleState
            if not PuzzleState.is_solvable(board_array_from_view, self.game.size):
                self.view.show_message("Input board is NOT solvable! Please rearrange or cancel.", "error")
                return # Không làm gì thêm nếu bảng không giải được

            # Tạo một đối tượng PuzzleState mới từ board_array người dùng cung cấp
            # Sử dụng goal_board_tuple mặc định từ self.game để đảm bảo tính nhất quán
            new_custom_state = PuzzleState(board_array_from_view, 
                                          self.game.default_goal_board_tuple, 
                                          self.game.size)
            
            # Cập nhật trạng thái hiện tại của game
            self.game.current_state = new_custom_state
            # Lưu lại trạng thái này để người dùng có thể "Reset" về nó
            self.game.initial_state_for_reset = copy.deepcopy(new_custom_state) 
            
            self.view.show_message("Custom board loaded and is solvable.", "success")
            self._update_view_with_current_board() # Yêu cầu View vẽ lại bảng mới
        except ValueError as e: # Bắt lỗi nếu PuzzleState không tạo được (ví dụ board sai kích thước)
            self.view.show_message(f"Error setting custom board: Invalid board data. {e}", "error")
        except Exception as e_gen: # Bắt các lỗi không lường trước khác
            self.view.show_message(f"Unexpected error setting custom board: {e_gen}", "error")
            print(f"UNEXPECTED_ERROR in GameController.set_custom_board: {e_gen}")
            import traceback
            traceback.print_exc() # In traceback chi tiết ra console để debug

    def request_current_board_display(self):
        """Được View gọi (ví dụ, sau khi hủy input mode) để yêu cầu vẽ lại bảng hiện tại."""
        if self.view:
            self._update_view_with_current_board()

    

    def _solve_task_wrapper(self, solver_name, heuristic_name=None, time_limit=None, state_limit=None):
        """
        Hàm bao bọc để thực thi solver.solve() trong một luồng riêng.
        Nó đặt kết quả vào self.solver_result_queue.
        """
        try:
            current_board_state_to_solve = copy.deepcopy(self.game.get_current_state())
            if not current_board_state_to_solve: # Kiểm tra nếu không có board hiện tại
                 self.solver_result_queue.put({"error": "No current board to solve.", "metrics": {"solution_found": False, "time_taken":0, "states_explored":0, "algorithm_name": solver_name}})
                 return

            solver_instance = None # Đổi tên biến để tránh nhầm lẫn với tham số solver_name

            # Khởi tạo solver dựa trên tên
            if solver_name.lower() == "bfs":
                solver_instance = BFSSolver(current_board_state_to_solve, timeout_seconds=time_limit, state_limit=state_limit)
            elif solver_name.lower() == "astar":
                solver_instance = AStarSolver(current_board_state_to_solve, heuristic_func_name=heuristic_name or "manhattan", 
                                     timeout_seconds=time_limit, state_limit=state_limit)
            elif solver_name.lower() == "dfs":
                # max_depth có thể được truyền từ params của PygameView hoặc mặc định ở đây
                solver_instance = DFSSolver(current_board_state_to_solve, timeout_seconds=time_limit, max_depth=30, state_limit=state_limit)
            elif solver_name.lower() == "ucs":
                solver_instance = UCSSolver(current_board_state_to_solve, timeout_seconds=time_limit, state_limit=state_limit)
            elif solver_name.lower() == "ids":
                # max_overall_depth có thể được truyền từ params hoặc mặc định
                solver_instance = IDSSolver(current_board_state_to_solve, timeout_seconds=time_limit, max_overall_depth=30)
            elif solver_name.lower() == "greedy":
                solver_instance = GreedySolver(current_board_state_to_solve, heuristic_func_name= "manhattan", 
                                             timeout_seconds=time_limit, state_limit=state_limit)
            elif solver_name.lower() == "idastar":
                solver_instance = IDAStarSolver(current_board_state_to_solve, heuristic_func_name="manhattan", 
                                              timeout_seconds=time_limit, node_expansion_limit=state_limit or 2000000) # state_limit là node_expansion_limit cho IDA*
            elif solver_name.lower() == "hill_climbing_simple":
                solver_instance = HillClimbingSolver(current_board_state_to_solve, timeout_seconds=time_limit, variant="simple")
            elif solver_name.lower() == "hill_climbing_steepest":
                solver_instance = HillClimbingSolver(current_board_state_to_solve, timeout_seconds=time_limit, variant="steepest_ascent")
            elif solver_name.lower() == "hill_climbing_stochastic":
                solver_instance = HillClimbingSolver(current_board_state_to_solve, timeout_seconds=time_limit, variant="stochastic")
            elif solver_name.lower() == "simulated_annealing":
                solver_instance = SimulatedAnnealingSolver(current_board_state_to_solve, timeout_seconds=time_limit)
            elif solver_name.lower() == "beam_search":
                # beam_width có thể được truyền từ params nếu bạn cấu hình trong PygameView
                solver_instance = BeamSearchSolver(current_board_state_to_solve, timeout_seconds=time_limit, beam_width=5) 
            elif solver_name.lower() == "genetic_algorithm":
                # Các tham số GA có thể được truyền từ params
                solver_instance = GeneticAlgorithmSolver(current_board_state_to_solve, timeout_seconds=time_limit)
            elif solver_name.lower() == "q_learning":
                # Các tham số episodes, alpha, gamma, epsilon có thể được cấu hình
                # hoặc truyền từ PygameView/params nếu muốn tùy chỉnh sâu hơn.
                # File Q-table cũng có thể được cấu hình.
                solver_instance = QLearningAgent(
                    current_board_state_to_solve, 
                    timeout_seconds=time_limit, # Timeout cho toàn bộ quá trình train+solve
                    episodes=5000,              # Số episodes huấn luyện
                    max_steps_per_episode=150,  # Giới hạn bước trong mỗi episode huấn luyện
                    q_table_filepath=os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'q_table_8puzzle.json') # Đường dẫn lưu Q-table
                )
            elif solver_name.lower() == "sarsa":
                solver_instance = SarsaAgent(
                    current_board_state_to_solve,
                    timeout_seconds=time_limit,
                    episodes=5000,
                    max_steps_per_episode=150,
                    q_table_filepath=os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'sarsa_q_table_8puzzle.json') # File riêng cho SARSA
                )
            # --- Thêm các khối elif cho các solver khác bạn đã triển khai ---
            # elif solver_name.lower() == "dfs":
            #     solver_instance = DFSSolver(current_board_state_to_solve, max_depth=params.get("max_depth", 30), timeout_seconds=time_limit)
            # elif solver_name.lower() == "ucs":
            #     solver_instance = UCSSolver(current_board_state_to_solve, timeout_seconds=time_limit, state_limit=state_limit)
            # elif solver_name.lower() == "ids":
            #     solver_instance = IDSSolver(current_board_state_to_solve, max_overall_depth=params.get("max_overall_depth", 30), timeout_seconds=time_limit)
            # elif solver_name.lower() == "greedy":
            #     solver_instance = GreedySolver(current_board_state_to_solve, heuristic_func_name=heuristic_name or "manhattan", timeout_seconds=time_limit, state_limit=state_limit)
            # elif solver_name.lower() == "idastar":
            #     solver_instance = IDAStarSolver(current_board_state_to_solve, heuristic_func_name=heuristic_name or "manhattan", timeout_seconds=time_limit, state_limit=state_limit)
            else:
                self.solver_result_queue.put({"error": f"Solver '{solver_name}' not implemented in controller.", "metrics": {"solution_found": False, "time_taken":0, "states_explored":0, "algorithm_name": solver_name}})
                return

            solution_found_flag = solver_instance.solve() # Gọi hàm solve của instance
            
            # Sau khi giải, solver_instance.solution_path và solver_instance.metrics đã được cập nhật
            self.solver_result_queue.put({
                "metrics": solver_instance.get_metrics(),
                "solution_path": solver_instance.get_solution_path() # Lấy path từ solver
            })

        except Exception as e:
            print(f"CONTROLLER_ERROR: Exception in solver thread for {solver_name}: {e}")
            import traceback
            traceback.print_exc()
            self.solver_result_queue.put({"error": str(e), "metrics": {"solution_found": False, "time_taken":0, "states_explored":0, "algorithm_name": solver_name}})

    def _run_single_solver_for_benchmark(self, solver_name, heuristic_name, puzzle_to_solve, time_limit, state_limit):
        """Chạy một solver cụ thể và trả về metrics của nó."""
        solver_instance = None
        solver_name_lower = solver_name.lower()

        # --- Logic tạo solver (tương tự như trong _solve_task_wrapper) ---
        if solver_name_lower == "bfs":
            solver_instance = BFSSolver(copy.deepcopy(puzzle_to_solve), timeout_seconds=time_limit, state_limit=state_limit)
        elif solver_name_lower == "dfs":
            solver_instance = DFSSolver(copy.deepcopy(puzzle_to_solve), timeout_seconds=time_limit, max_depth=30, state_limit=state_limit)
        elif solver_name_lower == "ucs":
            solver_instance = UCSSolver(copy.deepcopy(puzzle_to_solve), timeout_seconds=time_limit, state_limit=state_limit)
        elif solver_name_lower == "ids":
            solver_instance = IDSSolver(copy.deepcopy(puzzle_to_solve), timeout_seconds=time_limit, max_overall_depth=30)
        elif solver_name_lower == "greedy":
            solver_instance = GreedySolver(copy.deepcopy(puzzle_to_solve), heuristic_func_name=heuristic_name or "manhattan", 
                                         timeout_seconds=time_limit, state_limit=state_limit)
        elif solver_name_lower == "astar":
            solver_instance = AStarSolver(copy.deepcopy(puzzle_to_solve), heuristic_func_name=heuristic_name or "manhattan", 
                                 timeout_seconds=time_limit, state_limit=state_limit)
        elif solver_name_lower == "idastar":
            solver_instance = IDAStarSolver(copy.deepcopy(puzzle_to_solve), heuristic_func_name=heuristic_name or "manhattan", 
                                          timeout_seconds=time_limit, node_expansion_limit=state_limit or 2000000)
        # ... (Thêm các solver khác bạn muốn benchmark) ...
        else:
            print(f"BENCHMARK_CONTROLLER_WARN: Solver '{solver_name}' not recognized for benchmark.")
            return {"algorithm_name": solver_name, "solution_found": False, "error": "Not recognized"}

        if solver_instance:
            solver_instance.solve()
            metrics = solver_instance.get_metrics()
            # Thêm độ dài giải pháp vào metrics nếu tìm thấy
            if metrics.get("solution_found") and solver_instance.get_solution_path():
                metrics["solution_length"] = len(solver_instance.get_solution_path()) - 1
            else:
                metrics["solution_length"] = -1
            return metrics
        return {"algorithm_name": solver_name, "solution_found": False, "error": "Instance creation failed"}


    def _benchmark_task_wrapper(self, algorithms_to_benchmark, time_limit_per_solver, state_limit_per_solver):
        """Chạy benchmark cho các thuật toán được chỉ định."""
        if not self.current_puzzle_object:
            self.solver_result_queue.put({"benchmark_error": "No puzzle loaded for benchmark."})
            return

        benchmark_results_list = []
        puzzle_for_benchmark = copy.deepcopy(self.current_puzzle_object) # Dùng cùng 1 puzzle cho tất cả

        for algo_config in algorithms_to_benchmark: # algo_config là chuỗi như "bfs" hoặc "astar manhattan"
            parts = algo_config.split()
            solver_name = parts[0]
            heuristic_name = parts[1] if len(parts) > 1 else None
            
            print(f"BENCHMARK_CONTROLLER: Running {algo_config} on current puzzle...")
            if self.view: # Gửi thông báo cập nhật cho view
                self.view.show_message(f"Benchmarking: {algo_config}...", "info")
            
            # Chạy solver (không trong luồng riêng ở đây, vì _benchmark_task_wrapper đã ở trong luồng)
            metrics = self._run_single_solver_for_benchmark(
                solver_name, heuristic_name, puzzle_for_benchmark, 
                time_limit_per_solver, state_limit_per_solver
            )
            benchmark_results_list.append(metrics) # metrics đã chứa algorithm_name

        self.solver_result_queue.put({"benchmark_results": benchmark_results_list, "type": "benchmark_summary"}) # Thêm 'type' để dễ phân biệt


    def request_run_benchmark(self):
        """Được gọi từ View để bắt đầu benchmark."""
        if not self.current_puzzle_object:
            if self.view: self.view.show_message("Please load or set up a board first.", "warning")
            return
        if self.solver_thread and self.solver_thread.is_alive():
            if self.view: self.view.show_message("Another process is running. Please wait.", "warning")
            return

        # Danh sách các thuật toán và cấu hình heuristic bạn muốn benchmark
        # Lấy từ PygameView.solver_options_data để nhất quán
        # Hoặc định nghĩa một danh sách riêng cho benchmark ở đây
        algorithms_to_test_in_benchmark = []
        if self.view and hasattr(self.view, 'solver_options_data'):
            algorithms_to_test_in_benchmark = [item[1] for item in self.view.solver_options_data] # Lấy internal_key_combo
        else: # Fallback nếu view không có solver_options_data
            algorithms_to_test_in_benchmark = ["bfs", "astar manhattan"] # Ví dụ

        if not algorithms_to_test_in_benchmark:
             if self.view: self.view.show_message("No algorithms configured for benchmark.", "error")
             return


        time_limit_per_run = 10.0 # Giây, có thể cấu hình
        state_limit_per_run = 100000 # Số trạng thái, có thể cấu hình

        self.solver_thread = threading.Thread(
            target=self._benchmark_task_wrapper,
            args=(algorithms_to_test_in_benchmark, time_limit_per_run, state_limit_per_run),
            daemon=True
        )
        self.solver_thread.start()
        if self.view: self.view.show_message("Benchmark suite started...", "info")
        
        # View sẽ cần kiểm tra queue để lấy "benchmark_results"
        # và gọi một hàm mới trong view, ví dụ: self.view.display_benchmark_results(results_list)

    def request_solve_puzzle(self, solver_name_from_view, heuristic_name_from_view=None):
        """
        Được gọi từ View để bắt đầu quá trình giải puzzle trong một luồng mới.
        """
        if not self.game.current_state:
            if self.view: self.view.show_message("No puzzle board available to solve.", "error")
            return
        if self.solver_thread and self.solver_thread.is_alive():
            if self.view: self.view.show_message("A solver is already running. Please wait.", "warning")
            return

        if self.view:
            self.view.show_message(f"Attempting to solve with {solver_name_from_view.upper()}" + 
                               (f" (Heuristic: {heuristic_name_from_view})" if heuristic_name_from_view else "") + 
                               "...", "info")
        
        # Các tham số mặc định cho timeout và state limit (có thể lấy từ GUI sau này)
        time_limit_default = 30.0 
        state_limit_default = 200000 # Giới hạn số trạng thái khám phá

        self.solver_thread = threading.Thread(
            target=self._solve_task_wrapper,
            args=(solver_name_from_view, heuristic_name_from_view, time_limit_default, state_limit_default),
            daemon=True # Luồng sẽ tự động kết thúc khi chương trình chính thoát
        )
        self.solver_thread.start()
        if self.view: self.view.show_message(f"Solver {solver_name_from_view.upper()} started...", "info")


    def check_solver_results_for_view(self):
        """
        Được View gọi định kỳ (ví dụ qua root.after trong Tkinter, hoặc trong game loop của Pygame)
        để kiểm tra xem luồng solver đã hoàn thành và có kết quả trong queue chưa.
        Trả về True nếu có kết quả được xử lý (thành công hoặc lỗi), False nếu queue rỗng.
        """
        if not self.view: return False

        try:
            result = self.solver_result_queue.get_nowait() # Lấy không chặn, nếu rỗng sẽ raise queue.Empty
            
            if "error" in result:
                self.view.show_message(f"Solver error: {result['error']}", "error")
                if result.get("metrics"): # Vẫn hiển thị metrics nếu có (ví dụ: để biết thuật toán nào lỗi)
                     self.view.display_solve_results(None, result["metrics"])
            else:
                # Nếu giải thành công, current_state của game không tự động cập nhật thành trạng thái giải
                # View sẽ nhận solution_path (list các PuzzleState) và có thể tự quản lý việc hiển thị animation.
                # Hoặc controller có thể cập nhật self.game.current_state nếu muốn.
                # Hiện tại, View sẽ nhận path và tự xử lý việc hiển thị/animation.
                self.view.display_solve_results(
                    result.get("solution_path"),
                    result.get("metrics")
                )
            return True # Đã có kết quả và đã được gửi cho View để xử lý
        except queue.Empty:
            return False # Không có kết quả mới trong queue
        except Exception as e: # Bắt các lỗi không mong muốn khác khi xử lý queue
            self.view.show_message(f"System error checking solver results: {e}", "error")
            print(f"UNEXPECTED_ERROR in GameController.check_solver_results_for_view: {e}")
            import traceback
            traceback.print_exc()
            return True # Coi như đã xử lý lỗi để tránh vòng lặp vô hạn gọi hàm này