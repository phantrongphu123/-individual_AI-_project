# app/models/puzzle_game.py
from .puzzle_state import PuzzleState
import copy

class PuzzleGame:
    def __init__(self, size=3):
        self.size = size
        # Lấy goal tuple trực tiếp từ phương thức tĩnh
        self.default_goal_board_tuple = PuzzleState.get_default_goal_tuple(size)
        
        # Bây giờ generate_random_solvable_state có thể sử dụng goal_board_tuple này
        self.current_state = PuzzleState.generate_random_solvable_state(size, self.default_goal_board_tuple)
        self.initial_state_for_reset = copy.deepcopy(self.current_state)

    def randomize_board(self):
        self.current_state = PuzzleState.generate_random_solvable_state(self.size, self.default_goal_board_tuple)
        self.initial_state_for_reset = copy.deepcopy(self.current_state)
        print(f"GAME_LOGIC: Randomized board to: {self.current_state.board}")
        return self.current_state

    def reset_board_to_last_random(self):
        self.current_state = copy.deepcopy(self.initial_state_for_reset)
        print(f"GAME_LOGIC: Board reset to: {self.current_state.board}")
        return self.current_state

    def get_current_state(self):
        return self.current_state

    # Các hàm is_goal, get_possible_moves giờ nằm trong PuzzleState
    # PuzzleGame chỉ quản lý trạng thái hiện tại và các hành động cấp cao như randomize.