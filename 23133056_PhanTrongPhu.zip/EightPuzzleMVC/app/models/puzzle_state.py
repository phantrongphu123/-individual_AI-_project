# app/models/puzzle_state.py
import copy
import random

class PuzzleState:
    def __init__(self, board_array, goal_board_array=None, size=3):
        """
        board_array: list of lists, e.g., [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
        goal_board_array: a_tuple of tuples, e.g., ((1,2,3),(4,5,6),(7,8,0))
        """
        if not self._is_valid_board_format(board_array, size):
            raise ValueError("Invalid board format or size for PuzzleState.")
        
        self.board = [list(row) for row in board_array] # Ensure mutable list of lists
        self.size = size
        self.goal_board_tuple = goal_board_array if goal_board_array else self._generate_default_goal(size)
        self.blank_pos = self._find_blank()
        if self.blank_pos is None:
            raise ValueError("Board must contain a blank tile (0).")

    def _is_valid_board_format(self, board, size):
        if not isinstance(board, list) or len(board) != size:
            return False
        expected_numbers = set(range(size * size))
        current_numbers = set()
        for row in board:
            if not isinstance(row, list) or len(row) != size:
                return False
            for x in row:
                if not isinstance(x, int): return False
                current_numbers.add(x)
        return current_numbers == expected_numbers


    def _generate_default_goal(self, size):
        goal = []
        count = 1
        for r in range(size):
            row = []
            for c in range(size):
                if r == size - 1 and c == size - 1:
                    row.append(0) # Blank tile at the end
                else:
                    row.append(count)
                count += 1
            goal.append(tuple(row))
        return tuple(goal)

    def _find_blank(self):
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c] == 0:
                    return (r, c)
        return None # Should not happen if board is valid

    def get_board_tuple(self):
        """Returns an immutable (hashable) representation of the board."""
        return tuple(map(tuple, self.board))

    def is_goal(self):
        return self.get_board_tuple() == self.goal_board_tuple

    def get_possible_moves(self):
        """Returns a list of possible next PuzzleState objects."""
        moves = []
        br, bc = self.blank_pos
        # Possible deltas: (dr, dc, move_description)
        # Move descriptions can be tile numbers or directions
        for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            nr, nc = br + dr, bc + dc # New position of the tile to move INTO blank
            if 0 <= nr < self.size and 0 <= nc < self.size:
                new_board_array = [list(row) for row in self.board]
                # Swap blank with the tile
                new_board_array[br][bc], new_board_array[nr][nc] = new_board_array[nr][nc], new_board_array[br][bc]
                moves.append(PuzzleState(new_board_array, self.goal_board_tuple, self.size))
        return moves
    
    def manhattan_distance(self):
        """Calculates Manhattan distance heuristic to the goal state."""
        dist = 0
        goal_pos_cache = {} # Cache goal positions for faster lookup
        for r_goal in range(self.size):
            for c_goal in range(self.size):
                tile_val = self.goal_board_tuple[r_goal][c_goal]
                if tile_val != 0:
                    goal_pos_cache[tile_val] = (r_goal, c_goal)
        
        for r_curr in range(self.size):
            for c_curr in range(self.size):
                tile_val = self.board[r_curr][c_curr]
                if tile_val != 0:
                    if tile_val in goal_pos_cache:
                        gr, gc = goal_pos_cache[tile_val]
                        dist += abs(r_curr - gr) + abs(c_curr - gc)
                    else: # Should not happen if goal state is consistent
                        return float('inf') 
        return dist

    def __eq__(self, other):
        if not isinstance(other, PuzzleState):
            return NotImplemented
        return self.get_board_tuple() == other.get_board_tuple()

    def __hash__(self):
        return hash(self.get_board_tuple())

    def __lt__(self, other): # Needed for heapq if states are directly compared
        return False # Arbitrary, or implement a meaningful comparison

    def __repr__(self):
        return f"PuzzleState({self.board})"

    @staticmethod
    def get_inversions(flat_state):
        count = 0
        size = len(flat_state)
        for i in range(size):
            for j in range(i + 1, size):
                if flat_state[i] != 0 and flat_state[j] != 0 and flat_state[i] > flat_state[j]:
                    count += 1
        return count

    @staticmethod
    def is_solvable(board_array, size=3):
        """Checks if a given N-Puzzle state is solvable."""
        if size * size -1 < 0: return False # Handle empty or 1x1
        flat_board = [item for sublist in board_array for item in sublist]
        if 0 not in flat_board: return False # Must have a blank tile

        inversions = PuzzleState.get_inversions(flat_board)

        if size % 2 == 1: # Odd grid (e.g., 3x3, 5x5)
            return inversions % 2 == 0
        else: # Even grid (e.g., 2x2, 4x4)
            blank_row_from_bottom = 0
            for r in range(size):
                if 0 in board_array[r]:
                    blank_row_from_bottom = size - r
                    break
            if blank_row_from_bottom % 2 == 0: # Blank on an even row from bottom (1-indexed)
                return inversions % 2 == 1
            else: # Blank on an odd row from bottom
                return inversions % 2 == 0
    
    @staticmethod
    def generate_random_solvable_state(size=3, goal_board_array=None):
        if goal_board_array is None:
             # Generate default goal if not provided
            goal_state_temp = []
            count = 1
            for r in range(size):
                row_temp = []
                for c in range(size):
                    if r == size - 1 and c == size - 1: row_temp.append(0)
                    else: row_temp.append(count)
                    count += 1
                goal_state_temp.append(row_temp)
            goal_board_array = goal_state_temp

        if not PuzzleState.is_solvable(goal_board_array, size):
             print("Warning: Provided goal state itself is not solvable according to parity rules.")
             # This usually indicates an issue with the parity rule for the given goal.
             # For simplicity, we'll proceed but this might lead to issues if the
             # parity rule is strictly enforced for solvability against THIS goal.

        max_attempts = 1000
        for _ in range(max_attempts):
            flat = list(range(size * size))
            random.shuffle(flat)
            board_array = [flat[i*size:(i+1)*size] for i in range(size)]
            if PuzzleState.is_solvable(board_array, size): # Check solvability against standard goal or general parity
                return PuzzleState(board_array, tuple(map(tuple, goal_board_array)), size)
        print(f"Warning: Could not generate a solvable random state after {max_attempts} attempts. Returning goal state.")
        return PuzzleState(goal_board_array, tuple(map(tuple, goal_board_array)), size)
    
    @staticmethod
    def get_default_goal_tuple(size=3):
        goal = []
        count = 1
        for r in range(size):
            row = []
            for c in range(size):
                if r == size - 1 and c == size - 1:
                    row.append(0)
                else:
                    row.append(count)
                count += 1
            goal.append(tuple(row))
        return tuple(goal)