# app/models/solvers/search_solvers.py
from collections import deque
import heapq
import time
import copy
import itertools
from .solver_base import SolverBase
from app.models.puzzle_state import PuzzleState

class BFSSolver(SolverBase): # Giả sử bạn đã có phiên bản này hoạt động với PuzzleState
    def __init__(self, initial_puzzle_state, timeout_seconds=None, state_limit=500000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.state_limit = state_limit
        self.metrics["algorithm_name"] = "BFS"

    def solve(self):
        self._start_timer()
        queue = deque([(self.initial_state, [self.initial_state])]) 
        visited_boards = {self.initial_state.get_board_tuple()}

        while queue:
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] >= self.state_limit:
                self.metrics["state_limit_reached"] = True; break

            current_state_obj, path = queue.popleft()
            self.metrics["states_explored"] += 1

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                self.solution_path = path; break
            
            for neighbor_state_obj in current_state_obj.get_possible_moves():
                neighbor_board_tuple = neighbor_state_obj.get_board_tuple()
                if neighbor_board_tuple not in visited_boards:
                    visited_boards.add(neighbor_board_tuple)
                    queue.append((neighbor_state_obj, path + [neighbor_state_obj]))
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]

class DFSSolver(SolverBase): # Dựa trên logic DFS của bạn
    def __init__(self, initial_puzzle_state, timeout_seconds=None, max_depth=30, state_limit=750000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.max_depth = max_depth # max_depth_limit từ Puzzle của bạn
        self.state_limit = state_limit # MAX_DFS_POPS
        self.metrics["algorithm_name"] = f"DFS (DepthLimit={self.max_depth})"

    def solve(self):
        self._start_timer()
        # (state_obj, path_to_state_obj_list, current_depth)
        stack = [(self.initial_state, [self.initial_state], 0)]
        visited_boards = {self.initial_state.get_board_tuple()} # Tránh chu trình

        while stack:
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] >= self.state_limit:
                self.metrics["state_limit_reached"] = True; break

            current_state_obj, path, depth = stack.pop()
            self.metrics["states_explored"] += 1 # Đếm số lần pop

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                self.solution_path = path; break

            if depth >= self.max_depth: # Sử dụng max_depth của solver
                continue

            # reversed để mô phỏng thứ tự đệ quy (thăm con "trái" trước nếu get_possible_moves có thứ tự nhất quán)
            for neighbor_state_obj in reversed(current_state_obj.get_possible_moves()):
                neighbor_board_tuple = neighbor_state_obj.get_board_tuple()
                if neighbor_board_tuple not in visited_boards:
                    visited_boards.add(neighbor_board_tuple)
                    stack.append((neighbor_state_obj, path + [neighbor_state_obj], depth + 1))
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]

class UCSSolver(SolverBase): # Dựa trên logic UCS của bạn
    def __init__(self, initial_puzzle_state, timeout_seconds=None, state_limit=500000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.state_limit = state_limit
        self.metrics["algorithm_name"] = "UCS"

    def solve(self):
        self._start_timer()
        entry_count = itertools.count()
        initial_cost = 0 # g_cost
        # (cost, unique_id, state_obj, path_list)
        priority_queue = [(initial_cost, next(entry_count), self.initial_state, [self.initial_state])]
        # visited_g_costs: {board_tuple: min_g_cost}
        visited_g_costs = {self.initial_state.get_board_tuple(): initial_cost}
        
        while priority_queue:
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] >= self.state_limit:
                self.metrics["state_limit_reached"] = True; break

            cost, _, current_state_obj, path = heapq.heappop(priority_queue)
            current_board_tuple = current_state_obj.get_board_tuple()

            if cost > visited_g_costs.get(current_board_tuple, float('inf')):
                continue
            self.metrics["states_explored"] += 1

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                self.solution_path = path
                self.metrics["final_cost"] = cost; break

            for neighbor_state_obj in current_state_obj.get_possible_moves():
                neighbor_board_tuple = neighbor_state_obj.get_board_tuple()
                new_cost_to_neighbor = cost + 1 # Chi phí mỗi bước là 1

                if new_cost_to_neighbor < visited_g_costs.get(neighbor_board_tuple, float('inf')):
                    visited_g_costs[neighbor_board_tuple] = new_cost_to_neighbor
                    heapq.heappush(priority_queue, (new_cost_to_neighbor, next(entry_count), neighbor_state_obj, path + [neighbor_state_obj]))
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]

class IDSSolver(SolverBase): # Dựa trên logic IDDFS của bạn
    def __init__(self, initial_puzzle_state, timeout_seconds=None, max_overall_depth=30):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.max_overall_depth = max_overall_depth # max_depth_limit từ Puzzle cũ
        self.metrics["algorithm_name"] = f"IDS (MaxOverallDepth={self.max_overall_depth})"
        self._total_states_explored_in_ids = 0

    def _dls_recursive(self, current_state_obj, current_path_objs, depth_limit, visited_along_path_tuples):
        # visited_along_path_tuples là set các board_tuple TRÊN ĐƯỜNG ĐI HIỆN TẠI để tránh chu trình ngắn
        self._total_states_explored_in_ids += 1
        self.metrics["states_explored"] = self._total_states_explored_in_ids

        if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
            self.metrics["timeout_reached"] = True; return "timeout"
        
        if current_state_obj.is_goal():
            return current_path_objs

        if depth_limit == 0:
            return "cutoff"

        cutoff_occurred = False
        for neighbor_state_obj in current_state_obj.get_possible_moves():
            neighbor_tuple = neighbor_state_obj.get_board_tuple()
            if neighbor_tuple not in visited_along_path_tuples: # Chỉ cần kiểm tra không lặp lại trên path hiện tại
                result = self._dls_recursive(neighbor_state_obj, current_path_objs + [neighbor_state_obj], depth_limit - 1, visited_along_path_tuples | {neighbor_tuple})
                if result == "timeout": return "timeout"
                if result != "cutoff" and result is not None: return result
                if result == "cutoff": cutoff_occurred = True
        
        return "cutoff" if cutoff_occurred else None

    def solve(self):
        self._start_timer()
        self._total_states_explored_in_ids = 0

        for depth in range(self.max_overall_depth + 1):
            # print(f"IDS_SOLVE: Iteration with depth_limit = {depth}")
            # frozenset để có thể thêm vào set visited nếu cần (dù DLS thường không dùng visited toàn cục)
            result_path_objs = self._dls_recursive(
                self.initial_state, 
                [self.initial_state], 
                depth,
                frozenset({self.initial_state.get_board_tuple()}) 
            )

            if result_path_objs == "timeout":
                self.metrics["timeout_reached"] = True; break
            if result_path_objs != "cutoff" and result_path_objs is not None:
                self.metrics["solution_found"] = True
                self.solution_path = result_path_objs
                self.metrics["final_depth"] = depth; break
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]

class GreedySolver(SolverBase): # Dựa trên logic Greedy của bạn
    def __init__(self, initial_puzzle_state, heuristic_func_name="manhattan", timeout_seconds=None, state_limit=500000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.state_limit = state_limit # MAX_GREEDY_EXPANSIONS
        if heuristic_func_name == "manhattan":
            self.heuristic = lambda state_obj: state_obj.manhattan_distance()
        # elif heuristic_func_name == "misplaced":
        #     self.heuristic = lambda state_obj: state_obj.misplaced_tiles()
        else:
            raise ValueError(f"Unknown heuristic for Greedy: {heuristic_func_name}")
        self.metrics["algorithm_name"] = f"Greedy ({heuristic_func_name})"

    def solve(self):
        self._start_timer()
        entry_count = itertools.count()
        initial_h = self.heuristic(self.initial_state)
        if initial_h == float('inf'):
            self._stop_timer(); self.metrics["solution_found"] = False; return False

        # (h_score, unique_id, current_state_obj, path_list)
        priority_queue = [(initial_h, next(entry_count), self.initial_state, [self.initial_state])]
        visited_boards = {self.initial_state.get_board_tuple()}
        
        while priority_queue:
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] >= self.state_limit:
                self.metrics["state_limit_reached"] = True; break

            h_score, _, current_state_obj, path = heapq.heappop(priority_queue)
            self.metrics["states_explored"] += 1

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                self.solution_path = path
                self.metrics["final_heuristic_value"] = h_score; break

            for neighbor_state_obj in current_state_obj.get_possible_moves():
                neighbor_board_tuple = neighbor_state_obj.get_board_tuple()
                if neighbor_board_tuple not in visited_boards:
                    visited_boards.add(neighbor_board_tuple)
                    h_neighbor = self.heuristic(neighbor_state_obj)
                    if h_neighbor != float('inf'):
                        heapq.heappush(priority_queue, (h_neighbor, next(entry_count), neighbor_state_obj, path + [neighbor_state_obj]))
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]

class AStarSolver(SolverBase): # Giả sử bạn đã có phiên bản này hoạt động với PuzzleState
    def __init__(self, initial_puzzle_state, heuristic_func_name="manhattan", timeout_seconds=None, state_limit=300000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.state_limit = state_limit
        if heuristic_func_name == "manhattan":
            self.heuristic = lambda state_obj: state_obj.manhattan_distance()
        # elif heuristic_func_name == "misplaced":
        #     self.heuristic = lambda state_obj: state_obj.misplaced_tiles()
        else:
            raise ValueError(f"Unknown heuristic for A*: {heuristic_func_name}")
        self.metrics["algorithm_name"] = f"A* ({heuristic_func_name})"

    def solve(self):
        self._start_timer()
        entry_count = itertools.count()
        g_initial = 0
        h_initial = self.heuristic(self.initial_state)
        if h_initial == float('inf'):
            self._stop_timer(); self.metrics["solution_found"] = False; return False
        
        # (f_score, unique_id, g_score, state_obj, path_list)
        priority_queue = [(g_initial + h_initial, next(entry_count), g_initial, self.initial_state, [self.initial_state])]
        
        # g_costs: {board_tuple: min_g_score_to_reach_it}
        g_costs = {self.initial_state.get_board_tuple(): g_initial}
        
        while priority_queue:
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] >= self.state_limit:
                self.metrics["state_limit_reached"] = True; break

            f_score, _, g_score, current_state_obj, path = heapq.heappop(priority_queue)
            current_board_tuple = current_state_obj.get_board_tuple()

            # If a better path (lower g_score) to this state was already found and processed
            if g_score > g_costs.get(current_board_tuple, float('inf')):
                continue
            
            self.metrics["states_explored"] += 1

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                self.solution_path = path
                self.metrics["final_cost"] = g_score; break

            for neighbor_state_obj in current_state_obj.get_possible_moves():
                neighbor_board_tuple = neighbor_state_obj.get_board_tuple()
                tentative_g_score = g_score + 1 # Cost of each step is 1

                if tentative_g_score < g_costs.get(neighbor_board_tuple, float('inf')):
                    g_costs[neighbor_board_tuple] = tentative_g_score
                    h_neighbor = self.heuristic(neighbor_state_obj)
                    if h_neighbor != float('inf'):
                        f_neighbor = tentative_g_score + h_neighbor
                        heapq.heappush(priority_queue, (f_neighbor, next(entry_count), tentative_g_score, neighbor_state_obj, path + [neighbor_state_obj]))
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]


class IDAStarSolver(SolverBase): # Dựa trên logic IDA* của bạn
    def __init__(self, initial_puzzle_state, heuristic_func_name="manhattan", timeout_seconds=None, node_expansion_limit = 2000000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        if heuristic_func_name == "manhattan":
            self.heuristic = lambda state_obj: state_obj.manhattan_distance()
        # elif heuristic_func_name == "misplaced":
        #     self.heuristic = lambda state_obj: state_obj.misplaced_tiles()
        else:
            raise ValueError(f"Unknown heuristic for IDA*: {heuristic_func_name}")
        self.metrics["algorithm_name"] = f"IDA* ({heuristic_func_name})"
        self.node_limit = node_expansion_limit # MAX_IDA_STAR_NODES
        self._nodes_expanded_in_ida_total = 0 # Tổng số nút cho IDA*

    def _search_recursive_ida(self, current_path_objs, g_cost, f_cost_threshold):
        self._nodes_expanded_in_ida_total += 1
        self.metrics["states_explored"] = self._nodes_expanded_in_ida_total

        if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
            self.metrics["timeout_reached"] = True; return "timeout", float('inf')
        if self._nodes_expanded_in_ida_total > self.node_limit: # Kiểm tra tổng số nút
             self.metrics["state_limit_reached"] = True; return "cutoff", float('inf')

        current_state_obj = current_path_objs[-1]
        h_cost = self.heuristic(current_state_obj)
        if h_cost == float('inf'): return "cutoff", float('inf')

        current_f_cost = g_cost + h_cost

        if current_f_cost > f_cost_threshold:
            return "cutoff", current_f_cost

        if current_state_obj.is_goal():
            return current_path_objs, current_f_cost

        min_next_threshold = float('inf')
        current_path_tuples = frozenset(s.get_board_tuple() for s in current_path_objs)
        
        # Sắp xếp các con theo f-cost dự kiến có thể giúp tìm ngưỡng nhanh hơn
        neighbors_with_f = []
        for neighbor_state_obj in current_state_obj.get_possible_moves():
            if neighbor_state_obj.get_board_tuple() not in current_path_tuples:
                h_n = self.heuristic(neighbor_state_obj)
                if h_n != float('inf'):
                     neighbors_with_f.append((g_cost + 1 + h_n, neighbor_state_obj))
        neighbors_with_f.sort(key=lambda x: x[0])

        for _, neighbor_obj_sorted in neighbors_with_f:
            result, new_threshold_candidate = self._search_recursive_ida(
                current_path_objs + [neighbor_obj_sorted], g_cost + 1, f_cost_threshold
            )
            if result == "timeout": return "timeout", float('inf')
            if isinstance(result, list): return result, current_f_cost
            min_next_threshold = min(min_next_threshold, new_threshold_candidate)
        
        return "cutoff", min_next_threshold

    def solve(self):
        self._start_timer()
        self._nodes_expanded_in_ida_total = 0 # Reset cho mỗi lần solve

        current_f_threshold = self.heuristic(self.initial_state)
        if current_f_threshold == float('inf'):
            self._stop_timer(); self.metrics["solution_found"] = False; return False
            
        path_to_start = [self.initial_state]
        
        while True:
            # print(f"IDA* Iteration, f-threshold = {current_f_threshold:.2f}") # DEBUG
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if self.metrics["states_explored"] > self.node_limit : # Kiểm tra trước mỗi lần lặp lớn
                 self.metrics["state_limit_reached"] = True; break

            solution_or_status, next_threshold = self._search_recursive_ida(path_to_start, 0, current_f_threshold)

            if solution_or_status == "timeout":
                self.metrics["timeout_reached"] = True; break
            if isinstance(solution_or_status, list): # Solution found
                self.metrics["solution_found"] = True
                self.solution_path = solution_or_status
                self.metrics["final_cost"] = len(solution_or_status) - 1; break
            
            if next_threshold == float('inf'): break
            if next_threshold <= current_f_threshold: # Để tránh vòng lặp vô hạn
                if next_threshold == 0 and current_f_threshold == 0: # Đã ở đích nhưng is_goal chưa bắt được?
                    pass
                else:
                    print(f"IDA_STAR_WARN: Threshold did not increase significantly (new: {next_threshold}, old: {current_f_threshold}). Stopping."); break
            current_f_threshold = next_threshold
        
        self._stop_timer()
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]