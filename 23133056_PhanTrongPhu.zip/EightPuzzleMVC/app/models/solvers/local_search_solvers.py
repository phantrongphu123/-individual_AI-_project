# app/models/solvers/local_search_solvers.py
import random
import math
import time
import copy
import heapq # Cần cho Beam Search
from .solver_base import SolverBase
from app.models.puzzle_state import PuzzleState # Quan trọng

class HillClimbingSolver(SolverBase):
    def __init__(self, initial_puzzle_state, timeout_seconds=None, 
                 max_iterations=5000, variant="steepest_ascent"):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.max_iterations = max_iterations
        self.variant = variant.lower() # "simple", "steepest_ascent", "stochastic"
        # Đối với 8-puzzle, hàm heuristic (cần tối thiểu hóa) là hàm đánh giá trạng thái
        self.evaluation_function = lambda state_obj: state_obj.manhattan_distance()
        self.metrics["algorithm_name"] = f"HillClimbing ({self.variant})"
        self.metrics["local_search_steps"] = 0 # Đổi tên từ states_explored cho rõ nghĩa

    def solve(self):
        self._start_timer()
        # Hill Climbing thường bắt đầu từ trạng thái ban đầu được cung cấp
        current_state_obj = copy.deepcopy(self.initial_state)
        current_eval_score = self.evaluation_function(current_state_obj)
        
        # solution_path sẽ lưu trữ chuỗi các trạng thái (PuzzleState objects) đã đi qua
        self.solution_path = [current_state_obj] 

        for i in range(self.max_iterations):
            self.metrics["local_search_steps"] = i + 1
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break

            if current_state_obj.is_goal():
                self.metrics["solution_found"] = True
                # solution_path đã được cập nhật
                break

            neighbors = current_state_obj.get_possible_moves() # List các PuzzleState objects
            if not neighbors: # Không có nước đi nào, bị kẹt
                # print(f"HillClimbing ({self.variant}): No possible moves from current state.") # DEBUG
                break 

            next_state_obj = None
            best_neighbor_score = current_eval_score # Khởi tạo với điểm hiện tại

            if self.variant == "simple":
                random.shuffle(neighbors) 
                for neighbor in neighbors:
                    eval_neighbor = self.evaluation_function(neighbor)
                    if eval_neighbor < current_eval_score: # Tìm hàng xóm TỐT HƠN ĐẦU TIÊN
                        next_state_obj = neighbor
                        best_neighbor_score = eval_neighbor
                        break 
            
            elif self.variant == "steepest_ascent":
                best_candidate_neighbor = None
                # min_eval_for_steepest = current_eval_score # Sai, phải là float('inf') để tìm cái nhỏ hơn
                min_eval_for_steepest = float('inf') 

                # Để tránh bị kẹt nếu tất cả hàng xóm đều tệ hơn, ta vẫn có thể chọn hàng xóm "ít tệ nhất"
                # nếu muốn (không phải hill climbing chuẩn). Hill climbing chuẩn sẽ dừng.
                # Hiện tại, chỉ tìm hàng xóm TỐT HƠN.
                
                temp_neighbors = [] # Lưu các (score, neighbor_obj)
                for neighbor in neighbors:
                    eval_neighbor = self.evaluation_function(neighbor)
                    temp_neighbors.append((eval_neighbor, neighbor))
                
                if temp_neighbors:
                    temp_neighbors.sort(key=lambda x: x[0]) # Sắp xếp theo score tăng dần
                    if temp_neighbors[0][0] < current_eval_score: # Nếu hàng xóm tốt nhất thực sự tốt hơn
                        best_candidate_neighbor = temp_neighbors[0][1]
                        min_eval_for_steepest = temp_neighbors[0][0]
                
                if best_candidate_neighbor:
                    next_state_obj = best_candidate_neighbor
                    best_neighbor_score = min_eval_for_steepest
            
            elif self.variant == "stochastic":
                better_neighbors = [] # List các (score, PuzzleState_obj)
                for neighbor in neighbors:
                    eval_neighbor = self.evaluation_function(neighbor)
                    if eval_neighbor < current_eval_score:
                        better_neighbors.append((eval_neighbor, neighbor))
                
                if better_neighbors:
                    # Chọn ngẫu nhiên từ các hàng xóm TỐT HƠN
                    _, chosen_neighbor_obj = random.choice(better_neighbors)
                    next_state_obj = chosen_neighbor_obj
                    best_neighbor_score = self.evaluation_function(chosen_neighbor_obj)

            if next_state_obj and best_neighbor_score < current_eval_score: # Chỉ di chuyển nếu tìm thấy cải thiện
                current_state_obj = next_state_obj
                current_eval_score = best_neighbor_score
                self.solution_path.append(current_state_obj)
            else: # Bị kẹt ở cực tiểu địa phương hoặc cao nguyên phẳng
                # print(f"HillClimbing ({self.variant}): Stuck at local optimum/plateau after {i} iterations. Eval_score={current_eval_score}") # DEBUG
                break 
        
        self._stop_timer()
        # Kiểm tra lại lần cuối vì vòng lặp có thể dừng do max_iterations
        if not self.metrics["solution_found"] and current_state_obj.is_goal():
            self.metrics["solution_found"] = True
            # solution_path đã có trạng thái cuối
        
        self.metrics["final_heuristic_value"] = current_eval_score # Lưu điểm heuristic cuối cùng
        if self.metrics["solution_found"]:
            print(f"HillClimbing ({self.variant}): Solution found! Steps: {len(self.solution_path)-1}, Final_h: {current_eval_score}, Iterations: {self.metrics['local_search_steps']}, Time: {self.metrics['time_taken']:.4f}s")
        elif self.metrics.get("timeout_reached"):
             print(f"HillClimbing ({self.variant}): Timeout. Iterations: {self.metrics['local_search_steps']}, Time: {self.metrics['time_taken']:.4f}s, Current_h: {current_eval_score}")
        else:
             print(f"HillClimbing ({self.variant}): No solution found or stuck. Iterations: {self.metrics['local_search_steps']}, Time: {self.metrics['time_taken']:.4f}s, Final_h: {current_eval_score}")
        return self.metrics["solution_found"]


class SimulatedAnnealingSolver(SolverBase):
    def __init__(self, initial_puzzle_state, timeout_seconds=None,
                 initial_temp=100.0, final_temp=0.01, cooling_rate=0.997, 
                 max_total_iterations=30000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.initial_temp = initial_temp
        self.final_temp = final_temp
        self.cooling_rate = cooling_rate
        self.max_total_iterations = max_total_iterations
        self.evaluation_function = lambda state_obj: state_obj.manhattan_distance()
        self.metrics["algorithm_name"] = "SimulatedAnnealing"
        self.metrics["iterations_done"] = 0

    def solve(self):
        self._start_timer()
        current_state_obj = copy.deepcopy(self.initial_state)
        current_eval = self.evaluation_function(current_state_obj)
        
        best_state_so_far = current_state_obj
        best_eval_so_far = current_eval

        # self.solution_path sẽ lưu trạng thái tốt nhất tìm được (chỉ một trạng thái)
        self.solution_path = [best_state_so_far] 
        
        current_temp = self.initial_temp
        
        for iteration in range(self.max_total_iterations):
            self.metrics["iterations_done"] = iteration + 1
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            if current_temp <= self.final_temp: 
                # print(f"SA: Reached final temperature at iteration {iteration}.") # DEBUG
                break

            if current_state_obj.is_goal(): # Có thể tìm thấy giải pháp sớm
                best_state_so_far = current_state_obj
                best_eval_so_far = 0
                self.metrics["solution_found"] = True
                break

            possible_next_moves = current_state_obj.get_possible_moves()
            if not possible_next_moves: 
                # print(f"SA: No possible moves from current state at iteration {iteration}.") # DEBUG
                break 

            # Chọn một hàng xóm ngẫu nhiên
            next_state_candidate = random.choice(possible_next_moves)
            next_eval = self.evaluation_function(next_state_candidate)
            
            delta_e = next_eval - current_eval # Muốn delta_e < 0 (cải thiện)

            if delta_e < 0: # Nếu hàng xóm tốt hơn, luôn di chuyển
                current_state_obj = next_state_candidate
                current_eval = next_eval
                if current_eval < best_eval_so_far: # Cập nhật giải pháp tốt nhất toàn cục
                    best_state_so_far = copy.deepcopy(current_state_obj)
                    best_eval_so_far = current_eval
            else: # Nếu hàng xóm tệ hơn, chấp nhận với một xác suất
                if current_temp > 1e-9: 
                    acceptance_probability = math.exp(-delta_e / current_temp)
                    if random.random() < acceptance_probability:
                        current_state_obj = next_state_candidate
                        current_eval = next_eval
            
            current_temp *= self.cooling_rate # Giảm nhiệt độ
        
        self._stop_timer()
        # Cập nhật solution_path và puzzle_model của solver bằng trạng thái tốt nhất
        self.solution_path = [best_state_so_far] 
        self.initial_state = best_state_so_far # Để get_solved_puzzle_state có thể dùng

        if best_state_so_far.is_goal():
            self.metrics["solution_found"] = True
        
        self.metrics["final_heuristic_value"] = best_eval_so_far
        # print(f"SA: Found={self.metrics['solution_found']}, Iterations={self.metrics['iterations_done']}, Time={self.metrics['time_taken']:.4f}s, Final_h={best_eval_so_far}")
        return self.metrics["solution_found"]


class GeneticAlgorithmSolver(SolverBase):
    # ... (Giữ nguyên code GeneticAlgorithmSolver bạn đã có, đảm bảo nó:
    #      - Kế thừa từ SolverBase
    #      - Nhận initial_puzzle_state (có thể không dùng đến nếu tạo quần thể ngẫu nhiên)
    #      - Hàm _calculate_fitness sử dụng self.heuristic (ví dụ: state_obj.manhattan_distance())
    #      - Hàm _create_initial_population tạo các PuzzleState objects giải được.
    #      - Các toán tử _crossover và _mutation làm việc với PuzzleState objects và đảm bảo con cái giải được.
    #      - Cập nhật self.solution_path = [best_overall_individual] khi tìm thấy giải pháp.
    #      - Cập nhật self.metrics đúng cách.
    #      - Trả về True/False.
    # ) ...
    def __init__(self, initial_puzzle_state, timeout_seconds=None,
                 population_size=50, generations=100, 
                 mutation_rate=0.1, crossover_rate=0.7, elite_size=5, tournament_k=3):
        super().__init__(initial_puzzle_state, timeout_seconds) # initial_puzzle_state có thể chỉ để lấy goal và size
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.elite_size = elite_size 
        self.tournament_k = tournament_k
        self.evaluation_function = lambda state_obj: state_obj.manhattan_distance() # Hoặc heuristic khác
        self.metrics["algorithm_name"] = "GeneticAlgorithm"
        self.metrics["generations_done"] = 0

    def _create_initial_population(self):
        # ... (logic tạo quần thể PuzzleState objects giải được) ...
        population = []
        for _ in range(self.population_size):
            individual_state = PuzzleState.generate_random_solvable_state(
                self.initial_state.size, 
                self.initial_state.goal_board_tuple
            )
            population.append(individual_state)
        return population


    def _calculate_fitness(self, state_obj): # state_obj là PuzzleState
        # ... (logic tính fitness từ heuristic, ví dụ 1.0 / (1.0 + heuristic_value)) ...
        h = self.evaluation_function(state_obj)
        if h == float('inf'): return 0.0
        return 1.0 / (1.0 + h)

    def _selection(self, population_with_fitness):
        # ... (logic Tournament selection, trả về list các PuzzleState objects) ...
        selected_parents = []
        for _ in range(len(population_with_fitness)): 
            tournament = random.sample(population_with_fitness, min(self.tournament_k, len(population_with_fitness)))
            tournament.sort(key=lambda item: item[1], reverse=True) 
            selected_parents.append(tournament[0][0]) 
        return selected_parents

    def _crossover(self, parent1_state_obj, parent2_state_obj):
        # ... (logic Crossover, ví dụ Cycle Crossover, trả về 2 PuzzleState objects con) ...
        # ... (Đảm bảo con cái vẫn solvable) ...
        # Đây là ví dụ Cycle Crossover (CX1) đã có, bạn có thể dùng lại
        p1_flat = [item for sublist in parent1_state_obj.board for item in sublist]
        p2_flat = [item for sublist in parent2_state_obj.board for item in sublist]
        size_flat = len(p1_flat)
        child1_flat = [-1] * size_flat; child2_flat = [-1] * size_flat
        cycles = []; visited_indices = [False] * size_flat
        for i in range(size_flat):
            if not visited_indices[i]:
                current_cycle = []; start_index = i; current_index = i
                while not visited_indices[current_index]:
                    visited_indices[current_index] = True
                    current_cycle.append(current_index)
                    value_in_p2 = p2_flat[current_index]
                    try: current_index = p1_flat.index(value_in_p2)
                    except ValueError: return copy.deepcopy(parent1_state_obj), copy.deepcopy(parent2_state_obj)
                cycles.append(current_cycle)
        for i, cycle in enumerate(cycles):
            source1, source2 = (p1_flat, p2_flat) if i % 2 == 0 else (p2_flat, p1_flat)
            for index_in_cycle in cycle: # Đổi tên biến
                if 0 <= index_in_cycle < size_flat:
                     child1_flat[index_in_cycle] = source1[index_in_cycle]
                     child2_flat[index_in_cycle] = source2[index_in_cycle]
        
        def flat_to_board_array(flat_arr, board_s):
            return [flat_arr[i*board_s:(i+1)*board_s] for i in range(board_s)]

        child1_board_arr = flat_to_board_array(child1_flat, self.initial_state.size)
        child2_board_arr = flat_to_board_array(child2_flat, self.initial_state.size)

        if PuzzleState.is_solvable(child1_board_arr, self.initial_state.size):
            child1 = PuzzleState(child1_board_arr, self.goal_state_tuple, self.initial_state.size)
        else: child1 = copy.deepcopy(parent1_state_obj)
        
        if PuzzleState.is_solvable(child2_board_arr, self.initial_state.size):
            child2 = PuzzleState(child2_board_arr, self.goal_state_tuple, self.initial_state.size)
        else: child2 = copy.deepcopy(parent2_state_obj)
            
        return child1, child2


    def _mutation(self, state_obj):
        # ... (logic Mutation, ví dụ swap 2 ô, trả về PuzzleState object mới) ...
        # ... (Đảm bảo con cái vẫn solvable) ...
        mutated_board_array = [list(row) for row in state_obj.board]
        size = state_obj.size
        r1, c1 = random.randrange(size), random.randrange(size)
        r2, c2 = random.randrange(size), random.randrange(size)
        while (r1, c1) == (r2, c2):
            r2, c2 = random.randrange(size), random.randrange(size)
        mutated_board_array[r1][c1], mutated_board_array[r2][c2] = mutated_board_array[r2][c2], mutated_board_array[r1][c1]
        if PuzzleState.is_solvable(mutated_board_array, size):
            return PuzzleState(mutated_board_array, self.goal_state_tuple, size)
        return state_obj # Trả về gốc nếu đột biến không giải được

    def solve(self): # Ghi đè với logic GA
        # ... (Triển khai vòng lặp GA: đánh giá, lựa chọn, lai ghép, đột biến) ...
        # ... (Cập nhật self.solution_path = [best_individual_found_if_goal] và metrics) ...
        self._start_timer()
        # ... (logic GA như bạn đã có, đảm bảo cập nhật self.metrics["solution_found"] và self.solution_path) ...
        # ... (ví dụ từ code GA trước của bạn, điều chỉnh để dùng PuzzleState và self.evaluation_function)
        population = self._create_initial_population()
        if not population: self._stop_timer(); self.metrics["solution_found"] = False; return False

        best_overall_individual = None
        best_overall_fitness = -1.0

        for gen in range(self.generations):
            self.metrics["generations_done"] = gen + 1
            self.metrics["states_explored"] += self.population_size 

            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break

            population_with_fitness = []
            for individual_state in population:
                fitness = self._calculate_fitness(individual_state)
                population_with_fitness.append((individual_state, fitness))
                if fitness > best_overall_fitness:
                    best_overall_fitness = fitness
                    best_overall_individual = copy.deepcopy(individual_state)
                    if best_overall_individual.is_goal():
                        self.metrics["solution_found"] = True; break
            
            if self.metrics["solution_found"]: break
            population_with_fitness.sort(key=lambda x: x[1], reverse=True)
            
            next_population = [item[0] for item in population_with_fitness[:self.elite_size]]

            while len(next_population) < self.population_size:
                parents = self._selection(population_with_fitness)
                if len(parents) < 2: 
                    next_population.extend(parents) # Thêm nếu chỉ có 1
                    while len(next_population) < self.population_size and population: # Lấp đầy bằng cá thể ngẫu nhiên
                        next_population.append(self._create_initial_population()[0] if self._create_initial_population() else population[0])
                    break 
                parent1, parent2 = random.sample(parents, 2)
                child1, child2 = parent1, parent2
                if random.random() < self.crossover_rate: child1, child2 = self._crossover(parent1, parent2)
                if random.random() < self.mutation_rate: child1 = self._mutation(child1)
                if random.random() < self.mutation_rate: child2 = self._mutation(child2)
                next_population.append(child1)
                if len(next_population) < self.population_size: next_population.append(child2)
            population = next_population[:self.population_size]
        
        self._stop_timer()
        if best_overall_individual and best_overall_individual.is_goal():
            self.metrics["solution_found"] = True
        
        if self.metrics["solution_found"]:
            self.solution_path = [best_overall_individual]
            self.initial_state = best_overall_individual # Cập nhật trạng thái của solver
            self.metrics["final_heuristic_value"] = self.evaluation_function(best_overall_individual)
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]


class BeamSearchSolver(SolverBase):
    def __init__(self, initial_puzzle_state, timeout_seconds=None, beam_width=5, max_steps=1000):
        super().__init__(initial_puzzle_state, timeout_seconds)
        self.beam_width = beam_width
        self.max_steps = max_steps
        self.metrics["algorithm_name"] = f"BeamSearch (k={beam_width})"
        self.evaluation_function = lambda state_obj: state_obj.manhattan_distance() # Heuristic để đánh giá

    def solve(self):
        self._start_timer()
        
        # Beam: list of (heuristic_score, PuzzleState_object, path_list_of_PuzzleState_objs)
        # Sắp xếp theo heuristic_score tăng dần (tốt hơn là thấp hơn)
        # Dùng heapq để quản lý beam hiệu quả hơn nếu beam_width lớn,
        # nhưng với beam_width nhỏ, list và sort cũng được.
        # Ở đây dùng list và sort để đơn giản.
        current_beam = [(self.evaluation_function(self.initial_state), self.initial_state, [self.initial_state])]
        
        # Visited để tránh lặp lại trạng thái trong toàn bộ quá trình beam search, có thể rất tốn bộ nhớ
        # Beam search thường không dùng visited để giữ tính "tham lam" trong beam.
        # Nếu dùng, nó có thể giúp tránh lãng phí nhưng có thể bỏ lỡ giải pháp nếu beam width hẹp.
        # visited_board_tuples = {self.initial_state.get_board_tuple()}

        best_solution_path_found = None

        for step in range(self.max_steps):
            self.metrics["states_explored"] += len(current_beam)

            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            
            if not current_beam: break

            candidates = [] # (heuristic_score, PuzzleState_object, path_list)
            
            for h_parent, parent_state, parent_path in current_beam:
                if parent_state.is_goal():
                    if best_solution_path_found is None or len(parent_path) < len(best_solution_path_found):
                        best_solution_path_found = parent_path
                    # Beam search thường không dừng ngay khi tìm thấy giải pháp đầu tiên trong beam
                    # mà tiếp tục hết các trạng thái trong beam hiện tại để có thể tìm giải pháp tốt hơn.
                    # Tuy nhiên, nếu đã tìm thấy giải pháp, ta có thể không cần mở rộng nút này nữa.
                    continue # Đã là đích, không mở rộng con của nó nữa

                for neighbor_state in parent_state.get_possible_moves():
                    # neighbor_tuple = neighbor_state.get_board_tuple()
                    # if neighbor_tuple not in visited_board_tuples: # Nếu dùng visited
                        # visited_board_tuples.add(neighbor_tuple)
                    h_neighbor = self.evaluation_function(neighbor_state)
                    if h_neighbor != float('inf'):
                        candidates.append((h_neighbor, neighbor_state, parent_path + [neighbor_state]))
            
            if not candidates: # Không có trạng thái con nào được sinh ra từ toàn bộ beam
                break 

            # Sắp xếp tất cả các ứng viên và chọn ra beam_width ứng viên tốt nhất
            candidates.sort(key=lambda x: x[0]) # Sắp xếp theo heuristic
            current_beam = candidates[:self.beam_width]

            if not current_beam : break # Nếu sau khi lọc mà beam rỗng
        
        self._stop_timer()
        if best_solution_path_found:
            self.metrics["solution_found"] = True
            self.solution_path = best_solution_path_found
            self.metrics["final_cost"] = len(best_solution_path_found) - 1
        # Kiểm tra trạng thái tốt nhất cuối cùng trong beam nếu chưa tìm thấy giải pháp tối ưu
        elif current_beam and current_beam[0][1].is_goal():
             self.metrics["solution_found"] = True
             self.solution_path = current_beam[0][2]
             self.metrics["final_cost"] = len(current_beam[0][2]) - 1
        else:
            self.metrics["solution_found"] = False
        
        # ... (in thông báo kết quả) ...
        return self.metrics["solution_found"]