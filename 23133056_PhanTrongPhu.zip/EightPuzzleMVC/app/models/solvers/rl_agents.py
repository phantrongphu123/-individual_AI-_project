# app/models/solvers/rl_agents.py
import random
import time
import copy
import json # Cho việc lưu/tải Q-table
import os   # Để kiểm tra file tồn tại
from collections import defaultdict
from .solver_base import SolverBase
from app.models.puzzle_state import PuzzleState

class QLearningAgent(SolverBase):
    def __init__(self, initial_puzzle_state, timeout_seconds=None,
                 episodes=10000, alpha=0.1, gamma=0.90,
                 epsilon=1.0, epsilon_decay=0.9995, min_epsilon=0.05,
                 max_steps_per_episode=200, reward_goal=1.0, reward_step=-0.01, # Điều chỉnh reward
                 q_table_filepath="q_table_8puzzle.json"):
        
        super().__init__(initial_puzzle_state, timeout_seconds)
        
        self.episodes = episodes
        self.alpha = alpha
        self.gamma = gamma
        self.initial_epsilon = epsilon # Lưu epsilon ban đầu để có thể reset nếu train nhiều lần trên cùng instance
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.min_epsilon = min_epsilon
        self.max_steps_per_episode = max_steps_per_episode
        self.reward_goal = reward_goal
        self.reward_step = reward_step
        
        self.q_table_filepath = q_table_filepath
        self.q_table = self._load_q_table()
        
        self.metrics["algorithm_name"] = "QLearning"
        self.metrics["episodes_run"] = 0
        self.metrics["total_training_steps"] = 0
        self.metrics["final_epsilon"] = self.epsilon

    def _load_q_table(self):
        q_table_loaded = defaultdict(lambda: defaultdict(float))
        if not self.q_table_filepath or not os.path.exists(self.q_table_filepath):
            print(f"QLearning: No Q-table found at '{self.q_table_filepath}'. Starting fresh.")
            return q_table_loaded
        try:
            with open(self.q_table_filepath, 'r') as f:
                q_table_from_file_str_keys = json.load(f)
            loaded_count = 0
            for state_key_str, action_values_str_keys in q_table_from_file_str_keys.items():
                try:
                    state_tuple = eval(state_key_str) # CẢNH BÁO: eval()
                    if not (isinstance(state_tuple, tuple) and 
                            len(state_tuple) == self.initial_state.size and
                            all(isinstance(row, tuple) and len(row) == self.initial_state.size for row in state_tuple) and
                            all(all(isinstance(val, int) for val in row) for row in state_tuple)):
                        continue # Bỏ qua key không hợp lệ

                    q_table_loaded[state_tuple] = defaultdict(float)
                    for action_key_str, q_value in action_values_str_keys.items():
                        action_tuple = eval(action_key_str) # CẢNH BÁO: eval()
                        if not (isinstance(action_tuple, tuple) and 
                                len(action_tuple) == self.initial_state.size and # Action là next_state_tuple
                                all(isinstance(row, tuple) and len(row) == self.initial_state.size for row in action_tuple) and
                                all(all(isinstance(val, int) for val in row) for row in action_tuple)):
                            continue # Bỏ qua action key không hợp lệ
                        q_table_loaded[state_tuple][action_tuple] = q_value
                    if q_table_loaded[state_tuple]: # Chỉ tăng nếu có action hợp lệ được load cho state này
                        loaded_count +=1
                except: continue # Bỏ qua nếu eval lỗi
            if loaded_count > 0:
                print(f"QLearning: Q-table loaded from '{self.q_table_filepath}'. {loaded_count} states with actions.")
            else:
                print(f"QLearning: Q-table file '{self.q_table_filepath}' empty or no valid entries. Starting fresh.")
        except Exception as e:
            print(f"QLearning_ERROR: Loading Q-table from '{self.q_table_filepath}': {e}. Starting fresh.")
        return q_table_loaded

    def save_q_table(self):
        if not self.q_table_filepath:
            print("QLearning_WARN: No filepath for Q-table. Cannot save."); return
        q_table_to_save = {}
        for state_tuple, action_values in self.q_table.items():
            state_key_str = str(state_tuple)
            q_table_to_save[state_key_str] = {str(act_tuple): val for act_tuple, val in action_values.items()}
        try:
            directory = os.path.dirname(self.q_table_filepath)
            if directory and not os.path.exists(directory): os.makedirs(directory)
            with open(self.q_table_filepath, 'w') as f:
                json.dump(q_table_to_save, f, indent=2)
            print(f"QLearning: Q-table saved to '{self.q_table_filepath}'. {len(self.q_table)} states.")
        except Exception as e:
            print(f"QLearning_ERROR: Saving Q-table to '{self.q_table_filepath}': {e}")

    def _get_q_value(self, state_tuple, action_as_next_state_tuple):
        return self.q_table[state_tuple][action_as_next_state_tuple]

    def _get_possible_actions_and_next_states(self, current_state_obj: PuzzleState):
        possible_next_states = current_state_obj.get_possible_moves()
        return [(next_s, next_s.get_board_tuple()) for next_s in possible_next_states]

    def _choose_action(self, current_state_obj: PuzzleState):
        state_tuple = current_state_obj.get_board_tuple()
        actions_and_next_states = self._get_possible_actions_and_next_states(current_state_obj)
        if not actions_and_next_states: return None, None 
        if random.random() < self.epsilon:
            next_state_chosen, action_repr = random.choice(actions_and_next_states)
            return next_state_chosen, action_repr
        else:
            q_values_for_current_state = self.q_table[state_tuple]
            if not q_values_for_current_state:
                next_state_chosen, action_repr = random.choice(actions_and_next_states)
                return next_state_chosen, action_repr
            max_q = -float('inf'); best_action_repr_candidates = []
            possible_action_reprs = {ar_info[1] for ar_info in actions_and_next_states}
            # Lọc q_values_for_current_state để chỉ chứa các hành động hợp lệ
            valid_q_actions = {act_r: q_val for act_r, q_val in q_values_for_current_state.items() if act_r in possible_action_reprs}
            if not valid_q_actions: # Nếu không có Q-value nào cho các hành động hợp lệ, chọn ngẫu nhiên
                next_state_chosen, action_repr = random.choice(actions_and_next_states)
                return next_state_chosen, action_repr

            shuffled_valid_actions = list(valid_q_actions.items())
            random.shuffle(shuffled_valid_actions)
            for action_r, q_val in shuffled_valid_actions:
                if q_val > max_q: max_q = q_val; best_action_repr_candidates = [action_r]
                elif q_val == max_q: best_action_repr_candidates.append(action_r)
            if not best_action_repr_candidates:
                 next_state_chosen, action_repr = random.choice(actions_and_next_states)
                 return next_state_chosen, action_repr
            chosen_action_repr = random.choice(best_action_repr_candidates)
            for next_s_obj, act_r in actions_and_next_states:
                if act_r == chosen_action_repr: return next_s_obj, chosen_action_repr
            next_state_chosen, action_repr = random.choice(actions_and_next_states) # Fallback
            return next_state_chosen, action_repr

    def train(self):
        self._start_timer()
        print(f"QLearning: Training for {self.episodes} episodes. Initial epsilon: {self.epsilon:.4f}")
        actual_episodes_run = 0
        for episode in range(self.episodes):
            self.metrics["episodes_run"] = episode + 1; actual_episodes_run +=1
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            
            current_s_obj = PuzzleState.generate_random_solvable_state(
                self.initial_state.size, self.initial_state.goal_board_tuple)
            
            episode_steps = 0; episode_reward = 0
            for step in range(self.max_steps_per_episode):
                self.metrics["total_training_steps"] += 1
                s_tuple = current_s_obj.get_board_tuple()
                next_s_obj, action_as_next_s_tuple = self._choose_action(current_s_obj)
                if next_s_obj is None: break 
                reward = self.reward_step; is_done = False
                if next_s_obj.is_goal(): reward = self.reward_goal; is_done = True
                episode_reward += reward
                old_q_value = self._get_q_value(s_tuple, action_as_next_s_tuple)
                max_future_q = 0.0
                if not is_done:
                    q_values_for_next_s_actions = self.q_table.get(action_as_next_s_tuple, {})
                    if q_values_for_next_s_actions: max_future_q = max(q_values_for_next_s_actions.values())
                new_q_value = old_q_value + self.alpha * (reward + self.gamma * max_future_q - old_q_value)
                self.q_table[s_tuple][action_as_next_s_tuple] = new_q_value
                current_s_obj = next_s_obj; episode_steps += 1
                if is_done: break 
            
            self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
            self.metrics["final_epsilon"] = self.epsilon
            if episode % (self.episodes // 20 if self.episodes >=20 else 1) == 0:
                print(f"  QLearning Ep {episode}: Epsilon={self.epsilon:.4f}, Steps={episode_steps}, Reward={episode_reward:.2f}")
        
        self.save_q_table()
        self._stop_timer()
        print(f"QLearning: Training finished. Ran {actual_episodes_run} episodes. Total steps: {self.metrics['total_training_steps']}, Time: {self.metrics['time_taken']:.2f}s")
        return self._extract_policy_and_solve()

    def _extract_policy_and_solve(self):
        # ... (Giữ nguyên như phiên bản trước, đảm bảo sử dụng self._start_time_solve nếu muốn tách thời gian) ...
        print("QLearning: Extracting policy and solving from initial state...")
        self.solution_path = [self.initial_state]; current_eval_state = copy.deepcopy(self.initial_state)
        self.metrics["states_explored_in_solve"] = 0; start_solve_eval_time = time.time()
        self.metrics["solution_found"] = False # Reset trước khi thử giải

        for _ in range(self.max_steps_per_episode * 2):
            self.metrics["states_explored_in_solve"] += 1
            if current_eval_state.is_goal(): self.metrics["solution_found"] = True; break
            eval_state_tuple = current_eval_state.get_board_tuple()
            possible_actions_info = self._get_possible_actions_and_next_states(current_eval_state)
            if not possible_actions_info: print("QLearning Solve: Stuck, no possible moves."); break 
            q_values_for_actions = self.q_table.get(eval_state_tuple, {})
            best_next_state_obj = None
            if not q_values_for_actions: best_next_state_obj, _ = random.choice(possible_actions_info)
            else:
                max_q_val = -float('inf'); candidate_next_states_objs = []
                # Lọc các hành động hợp lệ từ q_values_for_actions
                valid_q_actions = {act_tuple: q_val for act_tuple, q_val in q_values_for_actions.items() 
                                   if any(act_tuple == pa_info[1] for pa_info in possible_actions_info)}

                if not valid_q_actions: # Nếu không có Q-value nào cho hành động hợp lệ, chọn ngẫu nhiên
                    best_next_state_obj, _ = random.choice(possible_actions_info)
                else:
                    for act_tuple, q_val in valid_q_actions.items():
                        if q_val > max_q_val: max_q_val = q_val; candidate_next_states_objs = [] # Reset candidates
                        if q_val >= max_q_val: # Bao gồm cả trường hợp bằng để thêm vào candidates
                            for next_s_obj_cand, act_r_cand in possible_actions_info:
                                if act_r_cand == act_tuple: candidate_next_states_objs.append(next_s_obj_cand)
                
                if not candidate_next_states_objs: best_next_state_obj, _ = random.choice(possible_actions_info)
                else: best_next_state_obj = random.choice(list(set(candidate_next_states_objs))) # Loại bỏ trùng lặp nếu có
            
            if not best_next_state_obj: print("QLearning Solve: Could not determine best next state."); break
            current_eval_state = best_next_state_obj; self.solution_path.append(current_eval_state)
        else: 
             if not current_eval_state.is_goal(): self.metrics["solution_found"] = False
        
        self.metrics["solve_time_after_training"] = time.time() - start_solve_eval_time
        if self.metrics["solution_found"]: print(f"QLearning: Policy extracted. Solution found in {len(self.solution_path)-1} moves.")
        else: print(f"QLearning: Policy extracted. No solution from initial state. Path len: {len(self.solution_path)-1}")
        return self.metrics["solution_found"]

    def solve(self): # Ghi đè SolverBase.solve()
        # self.epsilon = self.initial_epsilon # Uncomment nếu muốn reset epsilon mỗi lần gọi solve
        return self.train()


class SarsaAgent(QLearningAgent): # Kế thừa từ QLearningAgent để tái sử dụng nhiều hàm
    def __init__(self, initial_puzzle_state, **kwargs): # Nhận các tham số tương tự QLearning
        super().__init__(initial_puzzle_state, **kwargs)
        self.metrics["algorithm_name"] = "SARSA"

    def train(self): # Ghi đè hàm train
        self._start_timer()
        print(f"SARSA: Starting training for {self.episodes} episodes... Epsilon: {self.epsilon:.4f}")
        actual_episodes_run = 0

        for episode in range(self.episodes):
            self.metrics["episodes_run"] = episode + 1; actual_episodes_run +=1
            if self.timeout_seconds and (time.time() - self._start_time_solve > self.timeout_seconds):
                self.metrics["timeout_reached"] = True; break
            
            current_s_obj = PuzzleState.generate_random_solvable_state(
                self.initial_state.size, self.initial_state.goal_board_tuple)
            
            s_tuple = current_s_obj.get_board_tuple()
            # Chọn hành động A từ S bằng chính sách dựa trên Q (epsilon-greedy)
            next_s_obj_for_A, action_as_next_s_tuple_A = self._choose_action(current_s_obj)
            if next_s_obj_for_A is None: continue # Không có hành động nào từ trạng thái bắt đầu ngẫu nhiên

            episode_steps = 0; episode_reward = 0
            for step in range(self.max_steps_per_episode):
                self.metrics["total_training_steps"] += 1
                
                # Thực hiện hành động A, nhận R và S'
                # Trong trường hợp này, next_s_obj_for_A chính là S'
                reward = self.reward_step
                is_done = False
                if next_s_obj_for_A.is_goal():
                    reward = self.reward_goal
                    is_done = True
                episode_reward += reward
                
                # Chọn hành động A' từ S' bằng chính sách dựa trên Q (epsilon-greedy)
                next_s_obj_for_A_prime, action_as_next_s_tuple_A_prime = self._choose_action(next_s_obj_for_A)
                
                old_q_value = self._get_q_value(s_tuple, action_as_next_s_tuple_A)
                
                q_prime_value = 0.0
                if not is_done and next_s_obj_for_A_prime: # Nếu S' không phải là terminal và có hành động A'
                    q_prime_value = self._get_q_value(next_s_obj_for_A.get_board_tuple(), action_as_next_s_tuple_A_prime)
                
                new_q_value = old_q_value + self.alpha * (reward + self.gamma * q_prime_value - old_q_value)
                self.q_table[s_tuple][action_as_next_s_tuple_A] = new_q_value
                
                # S = S', A = A'
                current_s_obj = next_s_obj_for_A
                s_tuple = current_s_obj.get_board_tuple() # Hay action_as_next_s_tuple_A
                action_as_next_s_tuple_A = action_as_next_s_tuple_A_prime
                next_s_obj_for_A = next_s_obj_for_A_prime # Chuẩn bị cho S' của vòng lặp tiếp theo
                
                episode_steps += 1
                if is_done or next_s_obj_for_A is None: # Kết thúc episode
                    break
            
            self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)
            self.metrics["final_epsilon"] = self.epsilon
            if episode % (self.episodes // 20 if self.episodes >=20 else 1) == 0:
                print(f"  SARSA Episode {episode}/{self.episodes}, Epsilon: {self.epsilon:.4f}, Steps: {episode_steps}, Reward: {episode_reward:.2f}")

        self.save_q_table() # SARSA cũng có thể lưu Q-table
        self._stop_timer()
        print(f"SARSA: Training finished. Ran {actual_episodes_run} episodes. Total steps: {self.metrics['total_training_steps']}, Time: {self.metrics['time_taken']:.2f}s")
        return self._extract_policy_and_solve() # Dùng chung hàm trích xuất chính sách

# Các lớp DQNAgent, PolicyGradientAgent sẽ cần thư viện học sâu (TensorFlow/PyTorch)
# và cấu trúc phức tạp hơn nhiều.