# app/models/solvers/solver_base.py
from abc import ABC, abstractmethod
import time

class SolverBase(ABC):
    def __init__(self, initial_puzzle_state, timeout_seconds=None): # Nhận PuzzleState
        self.initial_state = initial_puzzle_state # PuzzleState object
        self.goal_state_tuple = initial_puzzle_state.goal_board_tuple
        self.solution_path = None # List of PuzzleState objects
        self.timeout_seconds = timeout_seconds
        self.metrics = {
            "time_taken": 0.0,
            "states_explored": 0,
            "solution_found": False,
            "timeout_reached": False,
            "algorithm_name": self.__class__.__name__
        }
        self._start_time_solve = 0

    @abstractmethod
    def solve(self):
        """
        Solves the puzzle.
        Should update self.solution_path and self.metrics.
        Returns True if solution found, False otherwise.
        """
        pass

    def get_solution_path(self):
        return self.solution_path

    def get_metrics(self):
        return self.metrics

    def _start_timer(self):
        self._start_time_solve = time.time()

    def _stop_timer(self):
        if hasattr(self, '_start_time_solve') and self._start_time_solve > 0:
            self.metrics["time_taken"] = time.time() - self._start_time_solve
        else:
            self.metrics["time_taken"] = -1.0