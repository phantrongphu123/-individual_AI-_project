# app/views/pygame_view.py
import pygame
import sys
import os
import threading
import queue
import time 
import copy

try:
    import tkinter as tk
    from tkinter import filedialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    print("PYGAME_VIEW_WARN: Tkinter (for filedialog) not found. Load puzzle from file might not work as expected.")

# --- Màu sắc ---
WHITE = (255, 255, 255); BLACK = (0, 0, 0); GREY = (180, 180, 180)
LIGHT_GREY = (220, 220, 220); DARK_GREY = (100, 100, 100)
RED = (220, 0, 0); GREEN = (0, 180, 0); BLUE_BTN = (60, 120, 180)
ORANGE = (255, 140, 0); INPUT_MODE_BG_COLOR = (200, 220, 255)
SELECTED_CELL_BORDER_COLOR = (0, 0, 200); TILE_BG_CORRECT = (144, 238, 144)
TILE_BG_INCORRECT = (255, 182, 193); TILE_BG_EMPTY_INPUT = (240, 240, 240)
CYAN = (0, 255, 255); MAGENTA = (255, 0, 255); YELLOW = (255, 255, 0)
LIGHT_BLUE = (173, 216, 230) # Thêm màu này nếu bạn dùng

# --- Lớp Button ---
class Button:
    def __init__(self, x, y, width, height, text, color, text_color, font, action=None, disabled_color=DARK_GREY, hover_color=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text; self.base_color = color
        self.hover_color = hover_color if hover_color else tuple(min(255, c + 30) for c in color[:3])
        self.disabled_color = disabled_color; self.text_color = text_color
        self.font = font; self.action = action
        self.benchmark_results_for_display = [] # Lưu kết quả benchmark để hiển thị
        self.is_hovered = False; self.is_disabled = False
    def draw(self, surface):
        current_color = self.disabled_color if self.is_disabled else (self.hover_color if self.is_hovered else self.base_color)
        pygame.draw.rect(surface, current_color, self.rect, border_radius=5)
        pygame.draw.rect(surface, BLACK, self.rect, 1, border_radius=5)
        text_surf = self.font.render(self.text, True, self.text_color if not self.is_disabled else GREY)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION: self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if not self.is_disabled and event.button == 1 and self.is_hovered and self.action:
                self.action(); return True
        return False

# --- Lớp PygameView ---
class PygameView:
    def __init__(self, controller, board_size=3, screen_width=750, screen_height=550):
        pygame.init(); pygame.font.init()
        self.controller = controller; self.board_size = board_size
        self.width = screen_width; self.height = screen_height
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
        pygame.display.set_caption(f"{self.board_size*self.board_size -1}-Puzzle Solver (Pygame)")

        try:
            font_size_tile_calc = max(18, int(60 / (self.board_size / 2.5))) if self.board_size > 0 else 50
            self.font_tile = pygame.font.SysFont("arial", font_size_tile_calc, bold=True)
            self.font_button = pygame.font.SysFont("arial", 17, bold=True)
            self.font_message = pygame.font.SysFont("arial", 15)
            self.font_small_text = pygame.font.SysFont("arial", 14)
        except pygame.error as e:
            print(f"PYGAME_FONT_ERROR: Defaulting fonts. Error: {e}")
            font_size_tile_fallback = max(18, int(60 / (self.board_size / 2.5))) if self.board_size > 0 else 50
            self.font_tile = pygame.font.Font(None, font_size_tile_fallback)
            self.font_button = pygame.font.Font(None, 22)
            self.font_message = pygame.font.Font(None, 20)
            self.font_small_text = pygame.font.Font(None, 18)

        self.current_puzzle_state_to_draw = None; self.buttons = []; self.messages = []
        self.animation_path = None; self.animation_step = 0; self.last_anim_time = 0
        self.anim_delay = 250; self.ui_panel_width = 230; self.grid_offset_x = 20
        self.grid_offset_y = 20; self._calculate_grid_layout()

        # --- SỬA ĐỔI self.solver_options thành self.solver_options_data ---
        self.solver_options_data = [
            # Uninformed Search
            ("And-or search tree", "bfs"),
            ("Belief state search", "ucs"), # Giả sử controller xử lý 'dfs'
            ("Searching with partially observation", "ucs"), # Giả sử controller xử lý 'ucs'

            # Reinforcement Learning
            ("Q-Learning Agent", "q_learning"),
            ("SARSA Agent", "sarsa")
            # ("Deep Q-Network (DQN)", "dqn"), # Khi bạn triển khai
            # ("Policy Gradient (REINFORCE)", "policy_gradient"), # Khi bạn triển khai
        ]
        self.selected_solver_idx = 0
        # -----------------------------------------------------------------
        self.loaded_puzzle_filepath = None
        self.solver_thread = None; self.solver_result_queue = queue.Queue()
        self.is_input_mode = False
        self.input_board_array = [[0] * self.board_size for _ in range(self.board_size)]
        self.current_input_number = 1; self.placed_numbers_in_input = set()
        self._create_ui_elements(); self.running = True

    def _calculate_grid_layout(self):
        # ... (Giữ nguyên) ...
        self.grid_area_width = self.width - self.ui_panel_width - self.grid_offset_x * 2 - 20
        self.grid_area_height = self.height - self.grid_offset_y * 2
        if self.board_size <= 0: self.tile_display_size = 50
        else: self.tile_display_size = min(self.grid_area_width, self.grid_area_height) // self.board_size
        self.actual_total_grid_width = self.tile_display_size * self.board_size
        self.actual_total_grid_height = self.tile_display_size * self.board_size
        self.current_grid_offset_x = self.grid_offset_x + (self.grid_area_width - self.actual_total_grid_width) // 2
        self.current_grid_offset_y = self.grid_offset_y + (self.grid_area_height - self.actual_total_grid_height) // 2


    def _create_ui_elements(self):
        # ... (Giữ nguyên logic tạo nút, đảm bảo action của nút "Solve" gọi _solve_puzzle_handler_proxy) ...
        self.buttons = []
        btn_x_base = self.width - self.ui_panel_width + 20; current_btn_y = self.grid_offset_y
        btn_w_base = self.ui_panel_width - 40; btn_h_base = 35; spacing = 8
        self.buttons.append(Button(btn_x_base, current_btn_y, btn_w_base, btn_h_base, "Randomize Board", BLUE_BTN, WHITE, self.font_button, self.controller.randomize_board))
        current_btn_y += btn_h_base + spacing
        self.buttons.append(Button(btn_x_base, current_btn_y, btn_w_base, btn_h_base, "Reset Board", BLUE_BTN, WHITE, self.font_button, self.controller.reset_board))
        current_btn_y += btn_h_base + spacing
        self.input_board_button = Button(btn_x_base, current_btn_y, btn_w_base, btn_h_base, "Input Board", DARK_GREY, WHITE, self.font_button, self._toggle_input_mode)
        self.buttons.append(self.input_board_button); current_btn_y += btn_h_base + spacing
        self.confirm_input_button = Button(btn_x_base, current_btn_y, (btn_w_base // 2) - 3, btn_h_base, "Confirm", GREEN, WHITE, self.font_button, self._confirm_board_input)
        self.buttons.append(self.confirm_input_button)
        self.cancel_input_button = Button(btn_x_base + (btn_w_base // 2) + 3, current_btn_y, (btn_w_base // 2) - 3, btn_h_base, "Cancel", RED, WHITE, self.font_button, self._cancel_input_mode)
        self.buttons.append(self.cancel_input_button); current_btn_y += btn_h_base + spacing * 2
        self.buttons.append(Button(btn_x_base, current_btn_y, (btn_w_base // 2) - 3, 30, "< Algo", GREY, BLACK, self.font_button, self._prev_solver))
        self.buttons.append(Button(btn_x_base + (btn_w_base // 2) + 3, current_btn_y, (btn_w_base // 2) - 3, 30, "Algo >", GREY, BLACK, self.font_button, self._next_solver))
        current_btn_y += 30 + spacing + 20 
        self.solve_button_ref = Button(btn_x_base, current_btn_y, btn_w_base, btn_h_base, "Solve Selected", GREEN, WHITE, self.font_button, self._solve_puzzle_handler_proxy)
        #benhmark
        # Ví dụ, đặt nút Benchmark dưới nút Solve
        y_after_solve_button = self.solve_button_ref.rect.bottom + spacing * 2

        self.benchmark_button = Button(btn_x_base, y_after_solve_button, btn_w_base, btn_h_base, "Run Benchmark", ORANGE, WHITE, self.font_button, self._run_benchmark_handler)
        self.benchmark_button.is_disabled = True # Ban đầu vô hiệu hóa, chỉ bật khi có puzzle

        
        self.buttons.append(self.solve_button_ref)
        self._update_button_states()

    def _update_button_states(self):
        # ... (Giữ nguyên) ...
        solver_is_running = self.controller.solver_thread and self.controller.solver_thread.is_alive()
        can_solve_or_reset = self.current_puzzle_state_to_draw is not None
        solver_is_running = self.controller.solver_thread and self.controller.solver_thread.is_alive()
        can_solve_or_reset_or_benchmark = self.current_puzzle_state_to_draw is not None
        
        if hasattr(self, 'solve_button_ref') and self.solve_button_ref:
            self.solve_button_ref.is_disabled = solver_is_running or self.is_input_mode or not can_solve_or_reset
        if hasattr(self, 'benchmark_button') and self.benchmark_button:
            self.benchmark_button.is_disabled = solver_is_running or self.is_input_mode or not can_solve_or_reset
        for btn in self.buttons:
            if btn.action in [self.controller.randomize_board, self.controller.reset_board, self._load_puzzle_from_file_handler]:
                btn.is_disabled = solver_is_running or self.is_input_mode
            elif btn.action in [self._prev_solver, self._next_solver]:
                 btn.is_disabled = solver_is_running or self.is_input_mode
            elif hasattr(self, 'input_board_button') and btn == self.input_board_button :
                 btn.is_disabled = solver_is_running; btn.text = "Exit Input" if self.is_input_mode else "Input Board"
            elif hasattr(self, 'confirm_input_button') and btn == self.confirm_input_button:
                btn.is_disabled = not self.is_input_mode or solver_is_running
            elif hasattr(self, 'cancel_input_button') and btn == self.cancel_input_button:
                btn.is_disabled = not self.is_input_mode or solver_is_running

    def _prev_solver(self):
        if self.solver_options_data: # Sử dụng solver_options_data
            self.selected_solver_idx = (self.selected_solver_idx - 1 + len(self.solver_options_data)) % len(self.solver_options_data)
            display_name, _ = self.solver_options_data[self.selected_solver_idx]
            self.show_message(f"Selected: {display_name}", BLACK)

    def _next_solver(self):
        if self.solver_options_data: # Sử dụng solver_options_data
            self.selected_solver_idx = (self.selected_solver_idx + 1) % len(self.solver_options_data)
            display_name, _ = self.solver_options_data[self.selected_solver_idx]
            self.show_message(f"Selected: {display_name}", BLACK)
    def _run_benchmark_handler(self):
        if not self.current_puzzle_state_to_draw:
            self.show_message("Please set up a board before running benchmark!", "warning")
            return
        if self.controller.solver_thread and self.controller.solver_thread.is_alive():
            self.show_message("Another process is running. Please wait.", "warning")
            return

        self.show_message("--- Starting Benchmark ---", "info_header")
        self.show_message("This may take a while...", "info")
        for btn in self.buttons: btn.is_disabled = True # Vô hiệu hóa tất cả các nút
        
        # Gọi controller để chạy benchmark trong một luồng riêng
        self.controller.request_run_benchmark()


    def display_benchmark_summary(self, benchmark_data_list):
        self.messages = [] # Xóa các message cũ
        self.show_message("--- Benchmark Summary ---", "info_header")
        if not benchmark_data_list:
            self.show_message("No benchmark data to display.", "info")
            self._update_button_states() # Kích hoạt lại nút
            return

        # Sắp xếp kết quả (ví dụ theo tên thuật toán, rồi thời gian)
        # benchmark_data_list.sort(key=lambda x: (x.get("Algorithm", ""), x.get("TimeTaken (s)", float('inf'))))

        for entry in benchmark_data_list:
            algo = entry.get("Algorithm", "N/A")
            params = entry.get("Parameters", "")
            puzzle_name = entry.get("Puzzle", "N/A") # Thêm thông tin puzzle nếu benchmark chạy trên nhiều puzzle
            found = entry.get("SolutionFound", False)
            timeout = entry.get("TimeoutReached", False)
            time_taken = entry.get("TimeTaken (s)", -1.0)
            states = entry.get("NodesExpanded", -1)
            length = entry.get("SolutionLength", -1)

            display_name = algo
            if params:
                display_name += f" ({params})"
            
            # Giới hạn độ dài tên để hiển thị gọn hơn
            display_name = display_name[:25] + "..." if len(display_name) > 28 else display_name


            status_msg = ""
            color_msg = BLACK
            if found:
                status_msg = f"Solved ({length} steps)"
                color_msg = GREEN
            elif timeout:
                status_msg = "TIMEOUT"
                color_msg = ORANGE
            elif entry.get("state_limit_reached"): # Giả sử bạn có key này
                status_msg = "LIMIT REACHED"
                color_msg = ORANGE
            elif entry.get("ErrorInSolver") == "Yes" or entry.get("error"):
                status_msg = "ERROR"
                color_msg = RED
            else:
                status_msg = "Not Solved"
                color_msg = RED
            
            # Định dạng dòng hiển thị
            # Ví dụ: Algo: BFS, Status: Solved (10 steps), Time: 0.123s, States: 1000
            # Bạn có thể cần điều chỉnh f-string và độ rộng cột cho đẹp
            # msg_line = f"{display_name:<30s} | {status_msg:<20s} | T: {time_taken:>7.3f}s | N: {states}"
            # Đơn giản hơn:
            msg_line = f"{algo}: {status_msg}, T:{time_taken:.2f}s, N:{states}"
            self.show_message(msg_line, color_msg)

        self.show_message("--- Benchmark Finished ---", "info_header")
        # Kích hoạt lại các nút sau khi benchmark xong và hiển thị kết quả
        self._update_button_states()

    def _load_puzzle_from_file_handler(self):
        # ... (Giữ nguyên) ...
        pass # Logic tải file của bạn

    def _solve_puzzle_handler_proxy(self):
        if not self.current_puzzle_state_to_draw:
            self.show_message("Please randomize or input a board first!", RED); return
        
        if not hasattr(self, 'solver_options_data') or not self.solver_options_data or \
           not (0 <= self.selected_solver_idx < len(self.solver_options_data)):
            self.show_message("No solver selected or invalid solver index.", RED); return
        
        _display_name_for_ui, solver_key_combo = self.solver_options_data[self.selected_solver_idx]
        
        parts = solver_key_combo.split()
        solver_name_internal = parts[0]
        heuristic_name_internal = parts[1] if len(parts) > 1 else None
        
        # RL agents không dùng heuristic theo cách này
        solvers_using_heuristic_arg = ["greedy", "astar", "idastar"]
        if solver_name_internal in solvers_using_heuristic_arg:
            if len(parts) > 1:
                heuristic_name_internal = parts[1]
            else: # Nếu là astar/greedy/idastar mà không có heuristic_name, báo lỗi hoặc dùng mặc định
                self.show_message(f"Heuristic name missing for {solver_name_internal.upper()}. Using default.", ORANGE)
                # heuristic_name_internal sẽ là None, controller sẽ dùng mặc định

        self._update_button_states()
        self.controller.request_solve_puzzle(solver_name_internal, heuristic_name_internal)

    def _toggle_input_mode(self): # Giữ nguyên
        # ...
        if self.solver_thread and self.solver_thread.is_alive():
            self.show_message("Cannot enter input mode while solver is running.", ORANGE); return
        self.is_input_mode = not self.is_input_mode
        if self.is_input_mode:
            self.input_board_array = [[0] * self.board_size for _ in range(self.board_size)]
            self.current_input_number = 1; self.placed_numbers_in_input = set()
            self.show_message(f"INPUT: Click cell for #{self.current_input_number}", BLUE_BTN)
            self.current_puzzle_state_to_draw = None; self.animation_path = None
        else: self._cancel_input_mode()
        self._update_button_states()

    def _cancel_input_mode(self): # Giữ nguyên
        # ...
        self.is_input_mode = False; self.input_board_array = [[0] * self.board_size for _ in range(self.board_size)]
        self.current_input_number = 1; self.placed_numbers_in_input = set()
        self.controller.request_current_board_display()
        self.show_message("Exited input mode.", BLACK); self._update_button_states()

    def _confirm_board_input(self): # Giữ nguyên
        # ...
        if not self.is_input_mode: return
        flat_input = [item for sublist in self.input_board_array for item in sublist]
        expected_numbers = set(range(self.board_size * self.board_size))
        if set(flat_input) != expected_numbers:
            self.show_message(f"Invalid: Place all numbers 0-{self.board_size*self.board_size-1} once.", RED); return
        from app.models.puzzle_state import PuzzleState 
        if PuzzleState.is_solvable(self.input_board_array, self.board_size):
            self.show_message("Board is solvable! Loading...", GREEN)
            self.controller.set_custom_board(copy.deepcopy(self.input_board_array))
            self.is_input_mode = False
        else: self.show_message("Board is NOT solvable! Rearrange or Cancel.", RED)
        self._update_button_states()


    def _handle_grid_click_for_input(self, mouse_pos): # Giữ nguyên
        # ...
        if not self.is_input_mode: return
        self._calculate_grid_layout(); mx, my = mouse_pos
        if not (self.current_grid_offset_x <= mx < self.current_grid_offset_x + self.actual_total_grid_width and
                self.current_grid_offset_y <= my < self.current_grid_offset_y + self.actual_total_grid_height): return
        c = (mx - self.current_grid_offset_x) // self.tile_display_size
        r = (my - self.current_grid_offset_y) // self.tile_display_size
        if 0 <= r < self.board_size and 0 <= c < self.board_size:
            max_num = self.board_size * self.board_size -1
            if self.input_board_array[r][c] == 0:
                if self.current_input_number > max_num and 0 not in self.placed_numbers_in_input: self.current_input_number = 0
                elif self.current_input_number in self.placed_numbers_in_input and self.current_input_number != 0:
                    self.show_message(f"Number {self.current_input_number} already placed.", ORANGE); return
                self.input_board_array[r][c] = self.current_input_number
                if self.current_input_number != 0: self.placed_numbers_in_input.add(self.current_input_number)
                if len(self.placed_numbers_in_input) == max_num :
                    if 0 not in self.placed_numbers_in_input: self.current_input_number = 0
                    else: self.show_message(f"Board ready. Click Confirm.", BLUE_BTN); return
                elif self.current_input_number == 0 : self.show_message(f"Board ready. Click Confirm.", BLUE_BTN); return
                else:
                    next_num_to_place = -1
                    for num_check in range(1, max_num + 1):
                        if num_check not in self.placed_numbers_in_input: next_num_to_place = num_check; break
                    if next_num_to_place != -1: self.current_input_number = next_num_to_place
                    else: self.current_input_number = 0
                self.show_message(f"INPUT: Click cell for #{self.current_input_number if self.current_input_number !=0 else '0 (Blank)'}", BLUE_BTN)
            elif self.input_board_array[r][c] != 0 :
                lifted_number = self.input_board_array[r][c]
                self.input_board_array[r][c] = 0
                if lifted_number in self.placed_numbers_in_input: self.placed_numbers_in_input.remove(lifted_number)
                self.current_input_number = lifted_number
                self.show_message(f"INPUT: Click cell to place {self.current_input_number}", BLUE_BTN)

    def display_board(self, puzzle_state_obj): # Giữ nguyên
        self.current_puzzle_state_to_draw = puzzle_state_obj
        self.animation_path = None; self.animation_step = 0
        self.is_input_mode = False 
        self._update_button_states()

    def display_solve_results(self, solution_path_list, metrics): # Giữ nguyên
        self.show_message("--- Solve Results ---", BLUE_BTN) # Sử dụng BLUE_BTN
        for key, value in metrics.items():
            val_str = f"{value:.4f}" if isinstance(value, float) else str(value)
            self.show_message(f"  {key}: {val_str}", BLACK)
        if metrics.get("solution_found", False):
            self.show_message("  => Solution FOUND!", GREEN)
            if solution_path_list:
                self.show_message(f"  Solution Length: {len(solution_path_list) -1} moves", BLACK)
                self.animation_path = solution_path_list; self.animation_step = 0
                self.last_anim_time = pygame.time.get_ticks()
            else: self.show_message("  (Solver found solution state directly)", BLACK)
        else:
            if metrics.get("timeout_reached", False): self.show_message("  => No solution (TIMEOUT).", RED)
            else: self.show_message("  => No solution found.", RED)
        self._update_button_states()

    def show_message(self, text, color_tuple_or_type_str): # Giữ nguyên
        actual_color_rgb = BLACK
        if isinstance(color_tuple_or_type_str, tuple): actual_color_rgb = color_tuple_or_type_str
        elif isinstance(color_tuple_or_type_str, str):
            type_colors_local = {"info": BLACK, "error": RED, "success": GREEN, "warning": ORANGE, "info_header": BLUE_BTN}
            actual_color_rgb = type_colors_local.get(color_tuple_or_type_str.lower(), BLACK)
        self.messages.append((text, actual_color_rgb))
        if len(self.messages) > 7: self.messages.pop(0)

    def _draw_grid(self): # Giữ nguyên
        self._calculate_grid_layout()
        board_to_render = None; current_bg = WHITE
        if self.is_input_mode: board_to_render = self.input_board_array; current_bg = INPUT_MODE_BG_COLOR
        elif self.current_puzzle_state_to_draw: board_to_render = self.current_puzzle_state_to_draw.board
        pygame.draw.rect(self.screen, current_bg, (self.current_grid_offset_x -2, self.current_grid_offset_y -2, self.actual_total_grid_width + 4, self.actual_total_grid_height + 4))
        pygame.draw.rect(self.screen, DARK_GREY, (self.current_grid_offset_x -2, self.current_grid_offset_y -2, self.actual_total_grid_width + 4, self.actual_total_grid_height + 4),1)
        if not board_to_render:
            pygame.draw.rect(self.screen, LIGHT_GREY, (self.current_grid_offset_x, self.current_grid_offset_y, self.actual_total_grid_width, self.actual_total_grid_height))
            no_puzzle_text = self.font_button.render("Randomize or Input Board", True, BLACK)
            text_rect = no_puzzle_text.get_rect(center=(self.current_grid_offset_x + self.actual_total_grid_width/2, self.current_grid_offset_y + self.actual_total_grid_height/2))
            self.screen.blit(no_puzzle_text, text_rect); return
        for r in range(self.board_size):
            for c in range(self.board_size):
                tile_val = board_to_render[r][c]
                rect = pygame.Rect(self.current_grid_offset_x + c * self.tile_display_size, self.current_grid_offset_y + r * self.tile_display_size, self.tile_display_size -1 , self.tile_display_size -1)
                tile_bg = TILE_BG_EMPTY_INPUT if self.is_input_mode and tile_val == 0 else GREY
                if not self.is_input_mode and tile_val != 0 and self.current_puzzle_state_to_draw and self.current_puzzle_state_to_draw.goal_board_tuple:
                     is_correct_pos = (self.current_puzzle_state_to_draw.goal_board_tuple[r][c] == tile_val)
                     tile_bg = TILE_BG_CORRECT if is_correct_pos else TILE_BG_INCORRECT
                elif self.is_input_mode and tile_val != 0: tile_bg = LIGHT_BLUE
                pygame.draw.rect(self.screen, tile_bg, rect, border_radius=3)
                if tile_val != 0:
                    text_surf = self.font_tile.render(str(tile_val), True, BLACK)
                    text_rect = text_surf.get_rect(center=rect.center)
                    self.screen.blit(text_surf, text_rect)
                border_thickness = 1; border_col = BLACK
                if self.is_input_mode and self.input_board_array[r][c] == 0 and self.current_input_number != 0:
                    border_col = SELECTED_CELL_BORDER_COLOR; border_thickness = 2
                pygame.draw.rect(self.screen, border_col, rect, border_thickness, border_radius=3)

    def _draw_ui_panel(self): # Sửa đổi để hiển thị tên display_name
        panel_x = self.width - self.ui_panel_width
        pygame.draw.rect(self.screen, LIGHT_GREY, (panel_x, 0, self.ui_panel_width, self.height))
        pygame.draw.line(self.screen, BLACK, (panel_x, 0), (panel_x, self.height), 2)
        for button in self.buttons: button.draw(self.screen)
        
        algo_button_y_base = self.grid_offset_y + 3 * (35+8) + 30 + 8 + 20 # Ước lượng
        for btn_check in self.buttons:
            if btn_check.action == self._next_solver: # Tìm nút "Algo >"
                algo_button_y_base = btn_check.rect.bottom + 10; break
        
        if hasattr(self, 'solver_options_data') and self.solver_options_data: # Sử dụng solver_options_data
            if 0 <= self.selected_solver_idx < len(self.solver_options_data):
                display_name_to_show, _ = self.solver_options_data[self.selected_solver_idx] # Lấy tên hiển thị
                solver_display_text = f"Algorithm: {display_name_to_show}" # Hiển thị display_name
                solver_text_surf = self.font_small_text.render(solver_display_text, True, BLACK)
                self.screen.blit(solver_text_surf, (panel_x + 10, algo_button_y_base))
        y_after_solver_text = algo_button_y_base + self.font_small_text.get_linesize() + 15

        info_display_y = y_after_solver_text
        if self.is_input_mode:
            input_mode_text = f"Placing: {self.current_input_number if self.current_input_number !=0 else '0 (Blank)'}"
            input_surf = self.font_small_text.render(input_mode_text, True, BLUE_BTN)
            self.screen.blit(input_surf, (panel_x + 10, info_display_y))
        elif self.current_puzzle_state_to_draw :
             board_info_text = f"Board: {self.current_puzzle_state_to_draw.size}x{self.current_puzzle_state_to_draw.size}"
             if hasattr(self, 'loaded_puzzle_filepath') and self.loaded_puzzle_filepath:
                 fname = os.path.basename(self.loaded_puzzle_filepath)
                 board_info_text = f"File: {fname[:20]}" + ("..." if len(fname)>20 else "")
             file_text_surf = self.font_small_text.render(board_info_text, True, BLACK)
             self.screen.blit(file_text_surf, (panel_x + 10, info_display_y))

        msg_panel_height = 200; msg_area_y_start = self.height - msg_panel_height - 10
        pygame.draw.rect(self.screen, WHITE, (panel_x + 5, msg_area_y_start, self.ui_panel_width - 10, msg_panel_height))
        pygame.draw.rect(self.screen, DARK_GREY, (panel_x + 5, msg_area_y_start, self.ui_panel_width - 10, msg_panel_height), 1)
        current_msg_y = msg_area_y_start + 5
        for text, msg_color in reversed(self.messages):
            if current_msg_y + self.font_message.get_height() < msg_area_y_start + msg_panel_height - 5 :
                try:
                    msg_surf = self.font_message.render(text, True, msg_color)
                    self.screen.blit(msg_surf, (panel_x + 10, current_msg_y))
                    current_msg_y += self.font_message.get_linesize() + 2
                except pygame.error as e: print(f"PYGAME_ERROR rendering msg: {e}")
                except Exception as e_gen: print(f"Generic error rendering msg: {e_gen}")
            else: break

    def run(self): # Giữ nguyên
        # ...
        clock = pygame.time.Clock()
        while self.running:
            current_time_ms = pygame.time.get_ticks()
            for event in pygame.event.get():
                if event.type == pygame.QUIT: self.running = False
                if event.type == pygame.VIDEORESIZE:
                    self.width, self.height = event.size; self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
                    self._calculate_grid_layout(); self._create_ui_elements()
                solver_is_running = self.controller.solver_thread and self.controller.solver_thread.is_alive()
                button_was_clicked = False
                if not solver_is_running:
                    for button in self.buttons:
                        if button.handle_event(event): button_was_clicked = True; break 
                if not button_was_clicked and self.is_input_mode and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not solver_is_running:
                    self._handle_grid_click_for_input(event.pos)
            if self.controller.check_solver_results_for_view(): self._update_button_states()
            if self.animation_path and current_time_ms - self.last_anim_time > self.anim_delay:
                if self.animation_step < len(self.animation_path):
                    self.current_puzzle_state_to_draw = self.animation_path[self.animation_step]
                    self.animation_step += 1; self.last_anim_time = current_time_ms
                else:
                    self.animation_path = None; self.animation_step = 0; self.show_message("Animation finished.", BLACK)
            self._update_button_states()
            self.screen.fill(WHITE); self._draw_grid(); self._draw_ui_panel()
            pygame.display.flip(); clock.tick(30)
        pygame.quit()

# --- Mock Controller for standalone testing ---
if __name__ == '__main__':
    # ... (Giữ nguyên MockControllerPygame để test) ...
    class MockControllerPygame:
        def __init__(self): self.view=None; self.current_state=None; self.solver_thread=None; self.solver_result_queue=queue.Queue(); self.game=type('MockGame',(),{'size':3,'default_goal_board_tuple':(((1,2,3),(4,5,6),(7,8,0)))})()
        def set_view(self,view):self.view=view
        def randomize_board(self):
            print(f"MockControllerPygame: Randomize board")
            from app.models.puzzle_state import PuzzleState
            self.current_state=PuzzleState.generate_random_solvable_state(self.game.size,self.game.default_goal_board_tuple)
            if self.view:self.view.display_board(self.current_state)
        def reset_board(self):self.randomize_board()
        def get_current_state(self):return self.current_state
        def request_current_board_display(self):
             if self.view and self.current_state:self.view.display_board(self.current_state)
             elif self.view:self.view.display_board(None)
        def set_custom_board(self,board_array):
            print(f"MockControllerPygame: Set custom board {board_array}")
            from app.models.puzzle_state import PuzzleState
            try:
                self.current_state=PuzzleState(board_array,self.game.default_goal_board_tuple,self.game.size)
                if self.view:self.view.display_board(self.current_state)
            except ValueError as e:
                 if self.view:self.view.show_message(f"Mock Error: {e}","error") # Truyền type
        def request_solve_puzzle(self,solver_name,heuristic_name=None):
            print(f"MockControllerPygame: Request Solve with {solver_name}, heuristic: {heuristic_name}")
            def mock_solve_task():
                time.sleep(0.2); mock_metrics={"time_taken":0.123,"states_explored":100,"solution_found":True}
                from app.models.puzzle_state import PuzzleState
                solved_state=PuzzleState([[1,2,3],[4,5,6],[7,8,0]],self.game.default_goal_board_tuple,self.game.size)
                mock_path=[self.current_state,solved_state] if self.current_state else [solved_state]
                self.solver_result_queue.put({"metrics":mock_metrics,"solution_path":mock_path})
                self.solver_thread=None
            if self.solver_thread and self.solver_thread.is_alive():print("MockControllerPygame: Solver already running.");return
            self.solver_thread=threading.Thread(target=mock_solve_task,daemon=True);self.solver_thread.start()
            if self.view:self.view.show_message(f"Solving with {solver_name}...","info") # Truyền type
        # Trong lớp PygameView
        def check_solver_results_for_view(self):
            if not self.controller: return False
            try:
                result = self.controller.solver_result_queue.get_nowait()
                
                result_type = result.get("type") # Lấy loại kết quả

                if result_type == "benchmark_summary" and "benchmark_results" in result: # Xử lý kết quả benchmark
                    self.display_benchmark_summary(result["benchmark_results"])
                elif "error" in result: # Lỗi từ solver đơn lẻ hoặc benchmark
                    self.show_message(f"Error: {result['error']}", "error")
                    if result.get("metrics"): 
                        self.display_solve_results(None, result["metrics"]) 
                elif "metrics" in result: # Kết quả giải của một solver đơn lẻ
                    self.display_solve_results(
                        result.get("solution_path"),
                        result.get("metrics")
                    )
                # (Thêm các loại kết quả khác nếu có)
                return True 
            except queue.Empty:
                return False 
            except Exception as e:
                self.show_message(f"System error checking results: {e}", "error")
                print(f"PYGAME_VIEW_ERROR checking results: {e}")
                import traceback; traceback.print_exc()
                return True
    
    mock_controller_pg = MockControllerPygame()
    app_pygame_view = PygameView(mock_controller_pg, board_size=3)
    mock_controller_pg.set_view(app_pygame_view)
    mock_controller_pg.randomize_board()
    app_pygame_view.run()