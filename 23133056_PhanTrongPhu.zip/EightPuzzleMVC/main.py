# main.py
import sys
import os
import pygame # Cần cho PygameView

# --- Xử lý sys.path ---
project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from app.controllers.game_controller import GameController
from app.views.pygame_view import PygameView # Import PygameView mới

def main():
    print(f"CWD: {os.getcwd()}")
    
    PUZZLE_SIZE = 3 # Kích thước bảng 8-puzzle (3x3)
    
    controller = GameController(size=PUZZLE_SIZE)
    gui_view = PygameView(controller, board_size=PUZZLE_SIZE)
    
    controller.set_view(gui_view) # Liên kết Controller với View
    
    gui_view.run() # Chạy vòng lặp chính của Pygame

if __name__ == "__main__":
    main()